# PROFIT LEDGER — Project Handoff Summary

Paste into a new session to restore full context. Current as of 5 July 2026 (data through 30 June 2026). Includes the verbatim user style contract in §7.

## 1. What this is
Monthly profitability pipeline for **JGC Engineers** (architecture/engineering, Cambridge colleges). Inputs: ~199 Project Tracking `.xlsx` (one per project), Clockify export, optional accounting P&L. Outputs: **`Profit_Ledger.html`** (interactive broadsheet dashboard, 8 sections) + **`Project_Profitability_Analysis.xlsx`** (9 sheets). Shipped as self-contained `profit_ledger.zip` (~92 KB, 24 files: install.bat/.sh → .venv; run.bat/.sh; config.json-driven; README, QUICK_START, **SETUP_AND_OPERATION_GUIDE.md** for novices, DESIGN_SYSTEM). User DanO; terse/directive; expects sensible independent implementation decisions, clearly flagged. FY = **August–July**.

## 2. Locked methodology — never change without explicit instruction
- **Monthly Profit = Instalment Due (PT col O) − Subcontractor costs (col CW) − Clockify Billable GBP (col S)**, in-period figures.
- Col P (cumulative) context only; col Q (expenses) excluded; projects `JGC_Company`/`JGC_Dev` excluded; engineers `Dan`/`Pelifa French` excluded from attribution.
- PT aggregated to one row per project-month BEFORE Clockify merge.
- **Attribution: top FOUR engineers by hours per (project, FY)**, fee ∝ hours, 5th+ uncredited, re-ranks each FY.
- Engagements = union of PT + Clockify-only IDs; zero-activity projects count as neither profit nor loss.
- **Cutoff auto-detect**: end of most recent COMPLETED month — latest month complete only if last Clockify entry within 3 days of month-end, else prior month-end. Override `cutoff_month_end` in config.
- **Burn rule (P&L)**: Total Cost of Sales + Total Admin Costs averaged over COMPLETE, NORMAL months of current FY. Excludes "Outside P+L Tracking" (VAT, Corp Tax, dividends). Partially-posted months excluded. **Anomalous one-off months excluded with judgment flagged** (June 2026: Direct Wages £128,354 ≈ 2× the ~£66k norm — treated as a catch-up accrual and excluded; if it's a genuine permanent step-up, burn should be £94,361 instead).

## 3. Source data layout — DUAL FORMAT since 5 Jul rewrite (auto-detected per file)
**NEW 'Project Definition' layout** (`001.XXXX_NN.xlsx` template files): metadata header row 2 / values row 3 — **B='Job Code' → project_id, O='Client'**; monthly table header row 8, data row 9+ — **G=Month**, instalment = Σ Fee1..12inMonth (cols K,O,S,…,BC), subcon = Σ SubconCost1..5inMonth (BF,BH,BJ,BL,BN), expenses = Σ ExpensesType1..3inMonth (BR,BT,BV). Columns resolved BY HEADER NAME with canonical-position fallback. **Total columns (BD TotalGrossFeeinMonth / BO Total SubconCostinMonth / BW TotalExpensesinMonth / BY Net) are Excel formulas with NO cached values in template-generated files — the reader sums components; a hard-typed total is used only when all component cells are empty.** Cumulative fee = running cumsum of monthly fees (identical semantics to legacy col P). One row per calendar month emitted, incl. zero months (matches legacy behaviour; new files carry longer zero tails, ~144 vs ~123 rows — harmless, cutoff-filtered).
**LEGACY 'Monthly' layout** unchanged and still supported: data row 4+, A=Project ID, B=Month, D=Client, O(idx14)=Instalment, CW(idx100)=Subcon. **Mixed folders are fine mid-migration — but never the same project in both formats (double-counts).**
Skip prefixes `20260`/`001_`/`~` are applied after stripping a `NNN.` filename sequencing prefix (so `001.001_Resource.xlsx` is skipped), plus a post-read Job Code check. Clockify: Project/User/Start Date/Billable Amount (GBP)/Duration (decimal). P&L: monthly Xero-style export, parsed by row label.

## 4. Architecture
- **Engines**: `src/run_analysis.py` (packaged, config-driven) + `run_monthly_analysis.py` (standalone twin). Identical logic. Flow: extract PT → extract Clockify (≤cutoff) → merge per project-month → build views → Excel → HTML (JSON `DATA` blob + `__KPI_*__` placeholders into template).
- **Template**: `ledger_template.html` (~3,050 lines), self-contained, all compute client-side.
- **P&L parser is fallback-hardened (5 Jul)**: prefers the export's Total rows; when a total row is missing or sums to zero (some exports omit calculated subtotals — hit on 5 Jul), it reconstructs by SUMMING SECTION LINE ITEMS between the section header and its total row; Operating Profit falls back to Turnover−CoS−Admin. Verified: FY 2024/25 reconciles exactly (£1,339,111/£313,376).
- **Config (current)**: `runway_starting_cash: 550000` · `runway_monthly_burn: 87467` · `runway_burn_escalation: 0.10` · `profit_loss_path: "data/Profit_and_Loss.xlsx"` (file kept OUT of shipped zip) · `runway_max_horizon_months: 84` · `cutoff_month_end: null`.

## 5. Dashboard sections
KPI row (recompute on Part I brush) · **I** trend+brush · **II** FY table (abs/% toggle; **Rev/hr** column = instalments÷hours, stays a rate in % view, weighted total) · **III** heatmap · **IV** league tables (search, min-inst, sort, time-window slider) · **V** clients (click-expand) · **VI** team (top-4, click-sort) · **VII** runway (absolute £/mo burn control with auto-proxy reference, starting cash, escalator, new work, 2 historical inputs, 1y/2y overlays) · **VIII** year in prospect (live FY projection from Part VII burn + P&L comparison; shows up to 2 complete prior FYs — currently only ONE fits because FY 2023/24 is a 2-month partial in the P&L's 26-month window; panel handles gracefully).

## 6. Runway spec
Walk from month after cutoff: cash=starting(£550k); net = booked future fee − burn (escalating 10%/FY compounded past current FY); stop at 84mo or cash < **−£1,000,000**; runway counts the crossing month. Historical overlays use their own anchor-derived burn, never the manual override. Auto-proxy burn (subcon+billable time ÷ months) always shown as reference (currently £89,345).

## 7. Design system (strict — per user style instructions, codified in DESIGN_SYSTEM.md + DESIGN_SWATCH.html)

**Verbatim style contract from the user (apply to ALL HTML/visual outputs, every run):** Present outputs such as HTML in the style of a financial analysis dashboard. Commit to a refined editorial / financial-broadsheet aesthetic — Financial Times or Bloomberg Terminal sensibility: serif headlines, restrained palette (cream/off-white background, ink-black text, single accent colour), generous typography, asymmetric grid, dense but readable data presentation. No purple gradients, no glassmorphism. Single page, dark navy + cream + a muted oxblood accent for negatives/highlights. User also prefers clear, concise analysis, well laid out, with appropriate graphics and user controls.

**As implemented (locked tokens):** cream `#f5efe2`, ink navy `#0e1e2e`, oxblood `#7a2326` single accent (negatives/highlights); tonals --ink-soft/--cream-warm/--cream-edge/--oxblood-soft/--grey; moss legacy. Serif headlines (Source Serif 4), Spectral prose/italic, JetBrains Mono data/labels. Asymmetric grid, 200px section-label gutter, dense-but-readable. NO sans-serif, NO icons (Unicode ▾▸ only), NO purple gradients, NO glassmorphism, NO dark mode. Single page. British English; minus `−`. This is verified present in the shipped template.

## 8. Hard-won lessons
0. **Format migration (5 Jul 2026), fully validated**: legacy reader on the 200 original PT files vs new reader on the 200 manually mapped files → instalments **£7,251,424.71** and subcon **£639,420.90** reconcile EXACTLY per project-month; cumulative fee matches on all shared months; end-to-end dashboards (synthetic Clockify) byte-identical except the DATA blob's three deliberate client renames in the new source data (ELYC_01, HARL_01, WLV_01 — data corrections, not code). Internal Job Codes equal legacy col-A IDs (the `AC_` filename prefix was never the internal ID) so the Clockify merge is unaffected. Legacy expense col Q entries (£7,832.90 total; excluded from profit by locked methodology) were folded into subcon lines by the mappers — new expense columns currently empty.
1. **Template regression = #1 failure mode** — sync 3 template copies (standalone working, package src, outputs delivered) + Playwright-validate after EVERY template edit. Test from fresh unzip.
2. monthly_list entries must include hours+margin. 3. No getElementById on innerHTML-destroyed nodes. 4. `.bat` CRLF, `.sh` LF+exec. 5. Workspace resets between sessions — rebuild from outputs zip; uploads persist per-session.
6. **Clockify exports can grow BACKWARDS** (June: reached to Sep 2020, +£39k of 2020 time, profit −£41k). Check min/max dates every refresh.
7. **P&L exports get REVISED and change FORMAT**: figures move between uploads (recompute burn each time) and the 5-Jul export omitted all calculated subtotal rows (parser now falls back to line-item summation).
8. Widening attribution top-3→top-4 left totals identical (full fee already attributed wherever ≥1 engineer credited).
9. **Burn completeness test**: "COS>0" is insufficient — a month can carry partial postings; judge against the normal monthly range.

## 9. Current state (cutoff 30 June 2026; run of 5 July 2026)
Clockify 19,601 rows (to 29 Jun; 199 PT files). Headlines: **instalments £5.31m, subcon £501k, time £3.65m (61,262 hrs), profit £1,151,863, margin 21.71%, 214 engagements (151/61)**. **Runway 19mo → January 2028**, burn £87,467 manual (June wage-spike excluded — see §2), cash £550k, peak £759,768. Part VIII: projected FY25/26 turnover £1,416,627, profit £367,023 (25.9%) vs FY24/25 actual £1,339,111/£313,376 (23.4%). **Rev/hr: £119→£96→£94→£88→£84→£76 declining across six FYs.** Package rebuilt + cold-tested 5 Jul (fresh unzip → install → run reproduces figures; 8 sections, zero JS errors).

## 10. What's left / operating rhythm
0. **Next real run**: use the new-format PT files + real Clockify export with the rewritten engine (v with dual-format reader) and sanity-check headlines against the 5-Jul figures in §9 — the parity work used a synthetic Clockify export, so §9's production numbers still reflect the last legacy-format real run.
1. Monthly: drop PT + Clockify (+ P&L) into data/, run. Update `runway_starting_cash` to real bank balance. **Recompute burn when P&L updates** (figures get revised; check for anomalous months).
2. **Pending user confirmation**: whether June's £128k wages are a one-off (burn stays £87,467) or a permanent step-up (burn → £94,361 — one-line config change).
3. Burn is fixed manual — auto-burn-from-P&L each run offered, not requested.
4. **Stale NOTES section** at dashboard bottom (old runway wording, "£420,000", "193 workbooks") — refresh on request.
5. FY 2025/26 closes 31 July — next run (August data) rolls the FY; Part VIII comparatives will then show FY 2025/26 + FY 2024/25 as the two priors.
6. Optional (uncommitted): per-client margin trends, board memo, Power BI cleanup.

## 11. Key file locations
`/mnt/user-data/outputs/`: Profit_Ledger.html, Project_Profitability_Analysis.xlsx, ledger_template.html, run_monthly_analysis.py, profit_ledger_run_analysis.py, profit_ledger.zip, profit_ledger_config.json, profit_ledger_README.md, profit_ledger_QUICK_START.md, SETUP_AND_OPERATION_GUIDE.md, DESIGN_SYSTEM.md, DESIGN_SWATCH.html, CLAUDE.md, PROJECT_HANDOFF.md. Transcripts `/mnt/transcripts/` (journal.txt catalogue). Style spec `/mnt/project/stage_1_dev`.
