"""
=============================================================================
PROJECT PROFITABILITY ANALYSIS — Engine Script
=============================================================================

This script does the work. End users normally don't invoke it directly;
they run `run.bat` (Windows) or `./run.sh` (macOS/Linux) at the package root.

WHAT IT DOES
------------
Reads a folder of "Project Tracking" .xlsx files plus a Clockify export, merges
them by Project ID, and produces TWO outputs:

  1. A multi-sheet Excel workbook (Project_Profitability_Analysis.xlsx).
  2. An HTML "Profit Ledger" dashboard styled as a financial broadsheet
     (Profit_Ledger.html).

Both are also copied into archive/{cutoff-date}/ for permanent record.

PROFITABILITY FORMULA
---------------------
Monthly Profit = Gross fee raised in month (Project Tracking)
               − Subcontractor costs paid in month
               − Clockify Billable Amount GBP (col S of Clockify)

SOURCE LAYOUTS (auto-detected per file)
---------------------------------------
NEW    'Project Definition' sheet ('001.XXXX_NN.xlsx' template files):
       gross fee   = Fee1..Fee12inMonth summed,
       subcon cost = SubconCost1..5inMonth summed,
       expenses    = ExpensesType1..3inMonth summed.
       Project ID = 'Job Code' (metadata row 3), Client = 'Client' (row 3).
       Total columns are Excel formulas with no cached values in
       template-generated files, so components are summed directly.
LEGACY 'Monthly' sheet: A=ID, B=Month, O=Instalment, P=Cumulative,
       Q=Expenses, CW=Subcon — unchanged from previous versions.
A data folder may contain a mixture of both formats.

All three inputs are MONTHLY (in-period) figures. The "Cumulative Fee" column
(P) is a running total and is shown in the detail sheet for context only —
it is NOT used in the profit calculation.

Project Expenses (col Q) are EXCLUDED — pass-through costs billed at cost.
JGC_Company and JGC_Dev are EXCLUDED by default — internal time codes.

The yearly view aggregates on the August–July financial year.

CONFIGURATION
-------------
All settings live in config.json at the package root. Edit that file
(not this script) to change cutoff dates, exclusions, output paths,
runway assumptions, etc. See README.md for the full reference.

The script is idempotent — running it again with the same inputs gives
the same outputs. Safe to re-run.

=============================================================================
"""

import json
import os
import re
import warnings
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
from openpyxl import Workbook, load_workbook
from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.formatting.rule import ColorScaleRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

warnings.filterwarnings("ignore")


# =============================================================================
# CONFIG — loaded from config.json in the package root.
#
# All paths are resolved relative to the package root (i.e. the folder
# containing config.json), not the current working directory. This means
# you can run the pipeline from any terminal location and it will find
# the data and write outputs to the right place.
# =============================================================================

def _find_package_root() -> Path:
    """Locate the package root by looking for config.json.

    Walks up from this script's location and from the current working
    directory until config.json is found.
    """
    # 1. Try the parent of this script (src/ is inside the package)
    script_parent = Path(__file__).resolve().parent.parent
    if (script_parent / "config.json").exists():
        return script_parent
    # 2. Try the current working directory
    cwd = Path.cwd().resolve()
    for candidate in [cwd, *cwd.parents]:
        if (candidate / "config.json").exists():
            return candidate
    raise SystemExit(
        "ERROR: Could not find config.json. It should sit at the root of the "
        "package, alongside the data/ and outputs/ folders."
    )


def _load_config():
    """Load and return the config from config.json at the package root."""
    root = _find_package_root()
    config_path = root / "config.json"
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            raw = json.load(f)
    except json.JSONDecodeError as e:
        raise SystemExit(
            f"ERROR: config.json is not valid JSON. {e}\n"
            f"Path: {config_path}"
        )

    # Resolve paths relative to the package root
    def rel(p):
        if p is None:
            return None
        path = Path(p)
        return path if path.is_absolute() else (root / path)

    return {
        "ROOT": root,
        "PROJECT_TRACKING_FOLDER": rel(raw.get("project_tracking_folder", "data/Project_Tracking")),
        "CLOCKIFY_EXPORT_PATH":    rel(raw.get("clockify_export_path", "data/Clockify_Export.xlsx")),
        "CUTOFF_MONTH_END":        raw.get("cutoff_month_end"),
        "OUTPUT_PATH":             rel(raw.get("excel_output", "outputs/Project_Profitability_Analysis.xlsx")),
        "HTML_OUTPUT_PATH":        rel(raw.get("html_output", "outputs/Profit_Ledger.html")) if raw.get("html_output") is not False else None,
        "HTML_TEMPLATE_PATH":      rel(raw.get("html_template", "src/ledger_template.html")),
        "ARCHIVE_FOLDER":          rel(raw.get("archive_folder", "archive")),
        "ARCHIVE_OUTPUTS":         bool(raw.get("archive_outputs", True)),
        "EXCLUDED_PROJECTS":       list(raw.get("excluded_projects", ["JGC_Company", "JGC_Dev"])),
        "EXCLUDED_ENGINEERS":      list(raw.get("excluded_engineers", ["Dan", "Pelifa French"])),
        "RUNWAY_STARTING_CASH":    float(raw.get("runway_starting_cash", 420_000.0)),
        "RUNWAY_BURN_ESCALATION":  float(raw.get("runway_burn_escalation", 0.10)),
        "RUNWAY_MONTHLY_BURN":     (None if raw.get("runway_monthly_burn", None) in (None, "", "null")
                                    else float(raw.get("runway_monthly_burn"))),
        "PROFIT_LOSS_PATH":        (rel(raw["profit_loss_path"]) if raw.get("profit_loss_path") else None),
        "RUNWAY_MAX_HORIZON_MONTHS": int(raw.get("runway_max_horizon_months", 84)),
        "FILENAME_SKIP_PREFIXES":  tuple(raw.get("filename_skip_prefixes", ["20260", "001_", "~"])),
    }


# Load config once at module level. All references below use these names.
_CFG = _load_config()
PROJECT_TRACKING_FOLDER    = _CFG["PROJECT_TRACKING_FOLDER"]
CLOCKIFY_EXPORT_PATH       = _CFG["CLOCKIFY_EXPORT_PATH"]
CUTOFF_MONTH_END           = _CFG["CUTOFF_MONTH_END"]
OUTPUT_PATH                = _CFG["OUTPUT_PATH"]
HTML_OUTPUT_PATH           = _CFG["HTML_OUTPUT_PATH"]
HTML_TEMPLATE_PATH         = _CFG["HTML_TEMPLATE_PATH"]
ARCHIVE_FOLDER             = _CFG["ARCHIVE_FOLDER"]
ARCHIVE_OUTPUTS            = _CFG["ARCHIVE_OUTPUTS"]
EXCLUDED_PROJECTS          = _CFG["EXCLUDED_PROJECTS"]
EXCLUDED_ENGINEERS         = _CFG["EXCLUDED_ENGINEERS"]
RUNWAY_STARTING_CASH       = _CFG["RUNWAY_STARTING_CASH"]
RUNWAY_BURN_ESCALATION     = _CFG["RUNWAY_BURN_ESCALATION"]
RUNWAY_MONTHLY_BURN        = _CFG["RUNWAY_MONTHLY_BURN"]
PROFIT_LOSS_PATH           = _CFG["PROFIT_LOSS_PATH"]
RUNWAY_MAX_HORIZON_MONTHS  = _CFG["RUNWAY_MAX_HORIZON_MONTHS"]
FILENAME_SKIP_PREFIXES     = _CFG["FILENAME_SKIP_PREFIXES"]


# =============================================================================
# STEP 1 — extract Project Tracking data
# =============================================================================

def _strip_filename_prefix(fname: str) -> str:
    """Return the filename with any 'NNN.' sequencing prefix removed.

    New-style Project Definition files are named like '001.CATS_01.xlsx' —
    a three-digit sequence number, a dot, then the historical project file
    name. Skip-prefix rules (templates, resource files) are applied to the
    name AFTER this prefix is removed, so '001.001_Resource.xlsx' is still
    recognised and skipped as a resource file.
    """
    return re.sub(r"^\d{3}\.", "", fname)


def _should_skip_file(fname: str) -> bool:
    """Apply the configured skip prefixes to both the raw filename and the
    filename with any 'NNN.' sequencing prefix stripped. Excel lock files
    ('~$...') are always skipped."""
    if fname.startswith("~"):
        return True
    if fname.startswith(FILENAME_SKIP_PREFIXES):
        # '001.' sequencing prefixes are NOT skip prefixes — only skip on the
        # raw name if it matches a non-sequencing prefix such as '20260'.
        if not re.match(r"^\d{3}\.", fname):
            return True
    return _strip_filename_prefix(fname).startswith(FILENAME_SKIP_PREFIXES)


# -----------------------------------------------------------------------------
# Format A (legacy): 'Monthly' sheet, one row per project-month line.
#   A=Project ID, B=Month, C=Stage, D=Client, O=Instalment, P=Cumulative fee,
#   Q=Expenses, CW=Subcontractor costs.
# -----------------------------------------------------------------------------

def _read_pt_monthly_sheet(wb, fname: str) -> list:
    """Read the legacy 'Monthly' sheet layout. Returns a list of row dicts."""
    ws = wb["Monthly"]
    rows = []
    for row in ws.iter_rows(min_row=4, max_row=1200, values_only=True):
        if len(row) < 101:
            continue
        project_id = row[0]    # A
        month = row[1]         # B
        stage = row[2]         # C
        client = row[3]        # D
        instalment = row[14]   # O
        cum_fee = row[15]      # P
        expenses = row[16]     # Q (read for completeness; not used)
        subcon = row[100]      # CW
        if not month or not project_id:
            continue
        if not isinstance(month, datetime):
            # Guards against 'Total:' summary rows in column B
            continue
        rows.append({
            "file": fname,
            "project_id": project_id,
            "month": month,
            "stage": stage,
            "client": client,
            "instalment_due": instalment if isinstance(instalment, (int, float)) else 0,
            "cumulative_fee": cum_fee if isinstance(cum_fee, (int, float)) else 0,
            "project_expenses": expenses if isinstance(expenses, (int, float)) else 0,
            "subcon_costs": subcon if isinstance(subcon, (int, float)) else 0,
        })
    return rows


# -----------------------------------------------------------------------------
# Format B (new): 'Project Definition' sheet.
#
#   Row 2  — project metadata header  (B='Job Code' ... O='Client' ...)
#   Row 3  — project metadata values  (Job Code, Job Name, Client, ...)
#   Row 8  — monthly table header     (B='JobCode', G='Month', then 12 fee
#            blocks, 5 subcontractor blocks, 3 expense blocks + total columns)
#   Row 9+ — one row per calendar month
#
#   Fee blocks:     Services{n} | Stages{n} | FeeType{n} | Fee{n}inMonth   n=1..12
#   Subcon blocks:  SubconService{n} | SubconCost{n}inMonth               n=1..5
#   Expense blocks: ExpensesType{n} | ExpensesType{n}inMonth              n=1..3
#
#   The total columns (TotalGrossFeeinMonth, Total SubconCostinMonth,
#   TotalExpensesinMonth, TotalNetFeeinMonth) are Excel FORMULAS. Files that
#   have never been opened and recalculated in Excel carry no cached values
#   for them, so this reader SUMS THE COMPONENT COLUMNS itself and only falls
#   back to a cached total when the components are empty but the total holds
#   a hard number (e.g. typed directly into the total cell).
#
#   Column positions are resolved BY HEADER NAME with a fall-back to the
#   canonical template positions, so modest layout drift won't break the read.
# -----------------------------------------------------------------------------

# Canonical 0-based column indices in the Project Definition monthly table
_PD_MONTH_IDX      = 6                              # G
_PD_FEE_IDXS       = list(range(10, 55, 4))         # K,O,S,W,...,BC  (Fee1..Fee12)
_PD_STAGE_IDXS     = list(range(8, 53, 4))          # I,M,Q,...,BA    (Stages1..12)
_PD_SUBCON_IDXS    = list(range(57, 66, 2))         # BF,BH,BJ,BL,BN  (SubconCost1..5)
_PD_EXPENSE_IDXS   = list(range(69, 74, 2))         # BR,BT,BV        (ExpensesType1..3)
_PD_TOT_GROSS_IDX  = 55                             # BD  TotalGrossFeeinMonth
_PD_TOT_SUBCON_IDX = 66                             # BO  Total SubconCostinMonth
_PD_TOT_EXP_IDX    = 74                             # BW  TotalExpensesinMonth


def _pd_resolve_columns(header_row: tuple) -> dict:
    """Map header names to 0-based indices, falling back to canonical positions."""
    name_to_idx = {str(v).strip(): i for i, v in enumerate(header_row) if v is not None}

    def find(name, fallback):
        return name_to_idx.get(name, fallback)

    return {
        "month":    find("Month", _PD_MONTH_IDX),
        "fees":     [find(f"Fee{n}inMonth", _PD_FEE_IDXS[n - 1]) for n in range(1, 13)],
        "stages":   [find(f"Stages{n}", _PD_STAGE_IDXS[n - 1]) for n in range(1, 13)],
        "subcons":  [find(f"SubconCost{n}inMonth", _PD_SUBCON_IDXS[n - 1]) for n in range(1, 6)],
        "expenses": [find(f"ExpensesType{n}inMonth", _PD_EXPENSE_IDXS[n - 1]) for n in range(1, 4)],
        "tot_gross":  find("TotalGrossFeeinMonth", _PD_TOT_GROSS_IDX),
        "tot_subcon": find("Total SubconCostinMonth", _PD_TOT_SUBCON_IDX),
        "tot_exp":    find("TotalExpensesinMonth", _PD_TOT_EXP_IDX),
    }


def _num(v):
    return float(v) if isinstance(v, (int, float)) else 0.0


def _pd_sum_block(row: tuple, idxs: list, total_idx: int) -> float:
    """Sum component cells; fall back to a cached numeric total if the
    components are empty but the total column holds a hard value."""
    vals = [row[i] for i in idxs if i < len(row)]
    total = sum(_num(v) for v in vals)
    if total == 0 and not any(isinstance(v, (int, float)) for v in vals):
        cached = row[total_idx] if total_idx < len(row) else None
        if isinstance(cached, (int, float)):
            return float(cached)
    return total


def _read_pt_project_definition(wb, fname: str) -> list:
    """Read the new 'Project Definition' sheet layout. Returns row dicts.

    Returns one row per calendar month (including zero-activity months, to
    match the legacy reader's behaviour), with the project's running
    cumulative fee computed as the cumsum of monthly gross fees — the same
    semantics as legacy column P.
    """
    ws = wb["Project Definition"]
    all_rows = list(ws.iter_rows(min_row=1, max_row=ws.max_row, values_only=True))

    # --- Locate the metadata header (col B == 'Job Code') and the monthly
    #     table header (col B == 'JobCode') within the first 15 rows ---
    meta_hdr_i = mon_hdr_i = None
    for i, r in enumerate(all_rows[:15]):
        b = r[1] if len(r) > 1 else None
        if b == "Job Code" and meta_hdr_i is None:
            meta_hdr_i = i
        if b == "JobCode" and mon_hdr_i is None:
            mon_hdr_i = i
    if mon_hdr_i is None:
        raise ValueError("No monthly table header (JobCode/Month) found on 'Project Definition' sheet")

    # --- Project metadata: Job Code and Client from the row below the header ---
    project_id = None
    client = None
    if meta_hdr_i is not None and meta_hdr_i + 1 < len(all_rows):
        hdr = all_rows[meta_hdr_i]
        val = all_rows[meta_hdr_i + 1]
        name_to_idx = {str(v).strip(): j for j, v in enumerate(hdr) if v is not None}
        jc_idx = name_to_idx.get("Job Code", 1)
        cl_idx = name_to_idx.get("Client", 14)
        project_id = val[jc_idx] if jc_idx < len(val) else None
        client = val[cl_idx] if cl_idx < len(val) else None
    if not project_id:
        # Fall back to the filename (sequencing prefix stripped)
        project_id = _strip_filename_prefix(fname).rsplit(".xlsx", 1)[0]
    project_id = str(project_id).strip()

    cols = _pd_resolve_columns(all_rows[mon_hdr_i])

    rows = []
    cumulative = 0.0
    for r in all_rows[mon_hdr_i + 1:]:
        month = r[cols["month"]] if cols["month"] < len(r) else None
        if not isinstance(month, datetime):
            continue
        instalment = _pd_sum_block(r, cols["fees"], cols["tot_gross"])
        subcon     = _pd_sum_block(r, cols["subcons"], cols["tot_subcon"])
        expenses   = _pd_sum_block(r, cols["expenses"], cols["tot_exp"])
        cumulative += instalment
        stages = []
        for i in cols["stages"]:
            v = r[i] if i < len(r) else None
            if v is not None and str(v).strip() and str(v).strip() not in stages:
                stages.append(str(v).strip())
        rows.append({
            "file": fname,
            "project_id": project_id,
            "month": month,
            "stage": " / ".join(stages) if stages else None,
            "client": client,
            "instalment_due": instalment,
            "cumulative_fee": cumulative,
            "project_expenses": expenses,
            "subcon_costs": subcon,
        })
    return rows


def extract_project_tracking(folder: Path) -> pd.DataFrame:
    """Read all project .xlsx files and return one row per project-month line.

    Supports BOTH source layouts, auto-detected per file:

      * NEW  — 'Project Definition' sheet ('001.XXXX_NN.xlsx' template files):
               monthly gross fee = sum of Fee1..Fee12inMonth, subcontractor
               cost = sum of SubconCost1..5inMonth, expenses = sum of
               ExpensesType1..3inMonth. Project ID and Client come from the
               metadata block (Job Code / Client, row 3). Cumulative fee is
               computed as the running total of monthly gross fees.

      * LEGACY — 'Monthly' sheet: columns A, B, C, D, O, P, Q, CW as before.

    A folder may contain a mixture of both formats (useful mid-migration).
    Note: a single project-month can have multiple lines in legacy files;
    they are kept here and aggregated in step 3.
    """
    files = sorted(
        f for f in os.listdir(folder)
        if f.endswith(".xlsx") and not _should_skip_file(f)
    )
    print(f"  Found {len(files)} project file(s)")
    if not files:
        raise SystemExit(
            f"\nERROR: No Project Tracking .xlsx files found in:\n"
            f"  {folder}\n\n"
            f"Drop one .xlsx file per project into this folder, then re-run. "
            f"Files starting with any of {list(FILENAME_SKIP_PREFIXES)!r} are skipped "
            f"(templates, resource files, lock files); a 'NNN.' sequencing prefix "
            f"is ignored when applying those rules."
        )

    rows = []
    errors = []
    n_new = n_legacy = 0
    for fname in files:
        try:
            wb = load_workbook(folder / fname, data_only=True, read_only=True)
            if "Project Definition" in wb.sheetnames:
                file_rows = _read_pt_project_definition(wb, fname)
                n_new += 1
            elif "Monthly" in wb.sheetnames:
                file_rows = _read_pt_monthly_sheet(wb, fname)
                n_legacy += 1
            else:
                errors.append((fname, "No 'Project Definition' or 'Monthly' sheet"))
                wb.close()
                continue
            # Post-read skip: resource/template files identified by Job Code
            if file_rows and str(file_rows[0]["project_id"]).startswith(FILENAME_SKIP_PREFIXES):
                wb.close()
                continue
            rows.extend(file_rows)
            wb.close()
        except Exception as e:
            errors.append((fname, str(e)))

    if errors:
        print(f"  Warning: {len(errors)} file(s) had errors:")
        for fn, msg in errors[:5]:
            print(f"    {fn}: {msg}")

    fmt_bits = []
    if n_new:
        fmt_bits.append(f"{n_new} Project Definition")
    if n_legacy:
        fmt_bits.append(f"{n_legacy} legacy Monthly")
    if fmt_bits:
        print(f"  Formats read: {', '.join(fmt_bits)}")

    df = pd.DataFrame(rows)
    if df.empty:
        raise SystemExit(
            "\nERROR: No project-month rows could be read from the Project "
            "Tracking files. Check that the files contain a 'Project Definition' "
            "(new layout) or 'Monthly' (legacy layout) sheet with data rows."
        )
    df["month"] = pd.to_datetime(df["month"])
    print(f"  Extracted {len(df)} project-month line(s) from {df['file'].nunique()} files")
    return df


# =============================================================================
# STEP 2 — extract Clockify data
# =============================================================================

def extract_clockify(path: Path, cutoff: str) -> pd.DataFrame:
    """Load the Clockify detailed export and aggregate to project-month."""
    df = pd.read_excel(path)
    df["Start Date"] = pd.to_datetime(df["Start Date"])
    df["month"] = df["Start Date"].values.astype("datetime64[M]").astype("datetime64[ns]")
    df = df[df["month"] <= cutoff].copy()
    print(f"  Loaded {len(df)} Clockify line(s), covering {df['Project'].nunique()} project(s)")
    return df


# =============================================================================
# STEP 3 — merge Project Tracking with Clockify (one row per project-month)
# =============================================================================

def merge_sources(df_pt: pd.DataFrame, df_cl: pd.DataFrame, cutoff: str,
                  excluded_projects: list) -> pd.DataFrame:
    """Combine both sources into a single one-row-per-project-month dataframe.

    CRITICAL: Project Tracking files can have multiple rows per project-month
    (e.g. several instalment lines). Both sides MUST be aggregated to one row
    per project-month BEFORE merging — otherwise the Clockify totals get
    duplicated onto every Project Tracking row in the same month.
    """
    df_pt = df_pt[df_pt["month"] <= cutoff].copy()

    # Capture client info before we collapse rows
    pt_client = (df_pt[df_pt["client"].notna() & (df_pt["client"].astype(str).str.strip() != "")]
                 .groupby("project_id")["client"].first())
    cl_client = df_cl[df_cl["Client"].notna()].groupby("Project")["Client"].first()

    # Aggregate Project Tracking to one row per project-month
    # - instalment, subcon, expenses: SUM within month
    # - cumulative_fee: MAX (it's a running total — take last value in month)
    pt_monthly = df_pt.groupby(["project_id", "month"]).agg(
        instalment_due=("instalment_due", "sum"),
        cumulative_fee=("cumulative_fee", "max"),
        project_expenses=("project_expenses", "sum"),
        subcon_costs=("subcon_costs", "sum"),
    ).reset_index()

    # Aggregate Clockify to one row per project-month
    cl_monthly = df_cl.groupby(["Project", "month"]).agg(
        clockify_hours=("Duration (decimal)", "sum"),
        clockify_billable_amount=("Billable Amount (GBP)", "sum"),
    ).reset_index()
    cl_monthly.columns = ["project_id", "month", "clockify_hours", "clockify_billable_amount"]

    # Outer merge — keep months that appear in either source
    combined = pd.merge(pt_monthly, cl_monthly, on=["project_id", "month"], how="outer")
    for c in ["instalment_due", "cumulative_fee", "project_expenses", "subcon_costs",
              "clockify_hours", "clockify_billable_amount"]:
        combined[c] = combined[c].fillna(0)

    # Client mapping (prefer PT name, fall back to Clockify)
    combined["client"] = (combined["project_id"].map(pt_client)
                          .fillna(combined["project_id"].map(cl_client))
                          .fillna(""))

    # Forward-fill cumulative fee (so months that only have Clockify data still carry the cum value)
    combined = combined.sort_values(["project_id", "month"]).copy()
    combined["cumulative_fee"] = combined.groupby("project_id")["cumulative_fee"].ffill().fillna(0)

    # Exclude internal-only projects
    before = len(combined)
    combined = combined[~combined["project_id"].isin(excluded_projects)].copy()
    print(f"  Excluded {before - len(combined)} row(s) for {excluded_projects}")

    # Profitability calculations
    # NOTE: Project Expenses (col Q) intentionally NOT included — pass-through to client.
    combined["monthly_profit"] = (
        combined["instalment_due"]
        - combined["subcon_costs"]
        - combined["clockify_billable_amount"]
    )
    combined["cum_instalment"] = combined.groupby("project_id")["instalment_due"].cumsum()
    combined["cum_subcon"] = combined.groupby("project_id")["subcon_costs"].cumsum()
    combined["cum_clockify_billable"] = combined.groupby("project_id")["clockify_billable_amount"].cumsum()
    combined["profit_to_date"] = (
        combined["cum_instalment"]
        - combined["cum_subcon"]
        - combined["cum_clockify_billable"]
    )

    combined = combined[combined["month"] <= cutoff].copy()
    combined["year"] = combined["month"].dt.year
    combined["year_month"] = combined["month"].dt.strftime("%Y-%m")
    print(f"  Merged dataset: {len(combined)} project-month row(s), {combined['project_id'].nunique()} project(s)")
    return combined


# =============================================================================
# STEP 4 — build the views (one DataFrame per output sheet)
# =============================================================================

def build_views(combined: pd.DataFrame) -> dict:
    """Return a dict of named DataFrames, one per sheet to be written."""

    # Detail: long table, active months only
    detail = combined[
        (combined["instalment_due"] != 0)
        | (combined["subcon_costs"] != 0)
        | (combined["clockify_billable_amount"] != 0)
        | (combined["cumulative_fee"] != 0)
    ].copy()
    detail = detail.sort_values(["project_id", "month"])
    detail_out = detail[[
        "project_id", "client", "year_month", "year",
        "instalment_due", "cumulative_fee", "subcon_costs", "cum_subcon",
        "clockify_hours", "clockify_billable_amount", "cum_clockify_billable",
        "monthly_profit", "profit_to_date",
    ]].copy()
    detail_out.columns = [
        "Project ID", "Client", "Month", "Year",
        "Instalment Due (£)", "Cumulative Fee (£)", "Subcontractor Costs (£)", "Cum. Subcon (£)",
        "Clockify Hours", "Clockify Billable (£)", "Cum. Clockify Billable (£)",
        "Monthly Profit (£)", "Profit to Date (£)",
    ]

    # Project summary: one row per project
    proj = combined.groupby("project_id").agg(
        Client=("client", "last"),
        First_Month=("month", "min"),
        Last_Active_Month=("month", "max"),
        Total_Instalments=("instalment_due", "sum"),
        Total_Subcon=("subcon_costs", "sum"),
        Total_Clockify_Billable=("clockify_billable_amount", "sum"),
        Total_Clockify_Hours=("clockify_hours", "sum"),
    ).reset_index()
    proj["Profit"] = proj["Total_Instalments"] - proj["Total_Subcon"] - proj["Total_Clockify_Billable"]
    proj["Margin_%"] = np.where(proj["Total_Instalments"] > 0,
                                 proj["Profit"] / proj["Total_Instalments"] * 100, np.nan)
    proj["Avg_Realised_Rate"] = np.where(
        proj["Total_Clockify_Hours"] > 0,
        (proj["Total_Instalments"] - proj["Total_Subcon"]) / proj["Total_Clockify_Hours"],
        np.nan,
    )
    proj = proj.sort_values("Profit", ascending=False).reset_index(drop=True)
    proj.columns = [
        "Project ID", "Client", "First Month", "Last Active Month",
        "Total Instalments (£)", "Total Subcon (£)", "Total Clockify Billable (£)",
        "Total Clockify Hours", "Profit (£)", "Margin %", "Avg Realised Rate (£/hr)",
    ]

    # Monthly rollup (whole business)
    monthly = combined.groupby("year_month").agg(
        Instalments=("instalment_due", "sum"),
        Subcon=("subcon_costs", "sum"),
        Clockify_Billable=("clockify_billable_amount", "sum"),
        Clockify_Hours=("clockify_hours", "sum"),
        Active_Projects=("project_id", lambda x: combined.loc[x.index]
                         .query("instalment_due!=0 or subcon_costs!=0 or clockify_billable_amount!=0")
                         ["project_id"].nunique()),
    ).reset_index()
    monthly["Profit"] = monthly["Instalments"] - monthly["Subcon"] - monthly["Clockify_Billable"]
    monthly["Margin_%"] = np.where(monthly["Instalments"] > 0,
                                    monthly["Profit"] / monthly["Instalments"] * 100, np.nan)
    monthly = monthly.sort_values("year_month")
    monthly.columns = ["Month", "Instalments (£)", "Subcon (£)", "Clockify Billable (£)",
                       "Clockify Hours", "Active Projects", "Profit (£)", "Margin %"]

    # Yearly rollup
    yearly = combined.groupby("year").agg(
        Instalments=("instalment_due", "sum"),
        Subcon=("subcon_costs", "sum"),
        Clockify_Billable=("clockify_billable_amount", "sum"),
        Clockify_Hours=("clockify_hours", "sum"),
        Projects=("project_id", lambda x: combined.loc[x.index]
                  .query("instalment_due!=0 or subcon_costs!=0 or clockify_billable_amount!=0")
                  ["project_id"].nunique()),
    ).reset_index()
    yearly["Profit"] = yearly["Instalments"] - yearly["Subcon"] - yearly["Clockify_Billable"]
    yearly["Margin_%"] = np.where(yearly["Instalments"] > 0,
                                   yearly["Profit"] / yearly["Instalments"] * 100, np.nan)
    yearly["Rev_per_Hour"] = np.where(yearly["Clockify_Hours"] > 0,
                                      yearly["Instalments"] / yearly["Clockify_Hours"], np.nan)
    # Keep Rev/Hour next to Hours for natural reading
    yearly = yearly[["year", "Instalments", "Subcon", "Clockify_Billable",
                     "Clockify_Hours", "Rev_per_Hour", "Projects", "Profit", "Margin_%"]]
    yearly.columns = ["Year", "Instalments (£)", "Subcon (£)", "Clockify Billable (£)",
                      "Clockify Hours", "Revenue / Hour (£)", "Projects", "Profit (£)", "Margin %"]

    # Client rollup
    client_rollup = combined.groupby("client").agg(
        Projects=("project_id", "nunique"),
        Instalments=("instalment_due", "sum"),
        Subcon=("subcon_costs", "sum"),
        Clockify_Billable=("clockify_billable_amount", "sum"),
        Clockify_Hours=("clockify_hours", "sum"),
    ).reset_index()
    client_rollup["Profit"] = (client_rollup["Instalments"] - client_rollup["Subcon"]
                                - client_rollup["Clockify_Billable"])
    client_rollup["Margin_%"] = np.where(client_rollup["Instalments"] > 0,
                                          client_rollup["Profit"] / client_rollup["Instalments"] * 100,
                                          np.nan)
    client_rollup = client_rollup.sort_values("Profit", ascending=False).reset_index(drop=True)
    client_rollup = client_rollup[client_rollup["client"].astype(str).str.strip() != ""]
    client_rollup.columns = ["Client", "# Projects", "Instalments (£)", "Subcon (£)",
                              "Clockify Billable (£)", "Clockify Hours", "Profit (£)", "Margin %"]

    # Profit pivots (project × month)
    client_lk = combined.groupby("project_id")["client"].last()
    pivot_profit = combined.pivot_table(index="project_id", columns="year_month",
                                         values="monthly_profit", aggfunc="sum", fill_value=0)
    pivot_profit.insert(0, "Client", pivot_profit.index.map(client_lk))
    pivot_profit["Total Profit"] = pivot_profit.iloc[:, 1:].sum(axis=1)
    pivot_profit = pivot_profit.sort_values("Total Profit", ascending=False).reset_index()

    pivot_cumprofit = combined.pivot_table(index="project_id", columns="year_month",
                                            values="profit_to_date", aggfunc="last")
    pivot_cumprofit.insert(0, "Client", pivot_cumprofit.index.map(client_lk))
    pivot_cumprofit = pivot_cumprofit.reset_index()

    return {
        "detail": detail_out, "proj": proj, "monthly": monthly, "yearly": yearly,
        "client": client_rollup, "pivot_profit": pivot_profit, "pivot_cumprofit": pivot_cumprofit,
    }


# =============================================================================
# STEP 5 — write the Excel workbook
# =============================================================================

# Styling constants
FONT = "Arial"
HDR_FONT = Font(name=FONT, bold=True, color="FFFFFF", size=11)
HDR_FILL = PatternFill("solid", start_color="1F3864")
SUBHDR_FONT = Font(name=FONT, bold=True, size=11, color="1F3864")
TITLE_FONT = Font(name=FONT, bold=True, size=16, color="1F3864")
SUBTITLE_FONT = Font(name=FONT, italic=True, size=10, color="595959")
BODY_FONT = Font(name=FONT, size=10)
BOLD_BODY = Font(name=FONT, size=10, bold=True)
TOTAL_FILL = PatternFill("solid", start_color="D9E1F2")
ALT_FILL = PatternFill("solid", start_color="F2F2F2")
BORDER_THIN = Border(
    left=Side(style="thin", color="BFBFBF"),
    right=Side(style="thin", color="BFBFBF"),
    top=Side(style="thin", color="BFBFBF"),
    bottom=Side(style="thin", color="BFBFBF"),
)
CENTER = Alignment(horizontal="center", vertical="center")
LEFT = Alignment(horizontal="left", vertical="center")
RIGHT = Alignment(horizontal="right", vertical="center")

FMT_GBP = "£#,##0;[Red](£#,##0);-"
FMT_GBP_DEC = "£#,##0.00;[Red](£#,##0.00);-"
FMT_PCT = "0.0%;[Red](0.0%);-"
FMT_PCT_NUM = '0.0"%";[Red](0.0"%");-'
FMT_NUM = "#,##0;[Red](#,##0);-"
FMT_HRS = "#,##0.0;[Red](#,##0.0);-"

MONEY_COLS = {
    "Instalment Due (£)", "Cumulative Fee (£)", "Subcontractor Costs (£)", "Cum. Subcon (£)",
    "Clockify Billable (£)", "Cum. Clockify Billable (£)", "Monthly Profit (£)", "Profit to Date (£)",
    "Total Instalments (£)", "Total Subcon (£)", "Total Clockify Billable (£)", "Profit (£)",
    "Instalments (£)", "Subcon (£)", "Revenue / Hour (£)",
}


def style_header_row(ws, row, ncols):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row, column=c)
        cell.font = HDR_FONT
        cell.fill = HDR_FILL
        cell.alignment = CENTER
        cell.border = BORDER_THIN


def autofit(ws, min_w=10, max_w=42):
    for col in ws.columns:
        try:
            letter = col[0].column_letter
        except Exception:
            continue
        m = min_w
        for cell in col:
            if cell.value is None:
                continue
            m = max(m, len(str(cell.value)))
        ws.column_dimensions[letter].width = min(max_w, m + 2)


def write_workbook(V: dict, output_path: Path, cutoff_str: str):
    wb = Workbook()
    wb.remove(wb.active)

    # ---- README (first tab) -------------------------------------------------
    ws = wb.create_sheet("README")
    ws["A1"] = "Project Profitability Analysis — Workbook Guide"
    ws["A1"].font = TITLE_FONT
    ws["A2"] = f"Built from Project Tracking files + Clockify_Export. Period: earliest data through {cutoff_str}."
    ws["A2"].font = SUBTITLE_FONT

    readme_rows = [
        ("", ""),
        ("Profitability formula",
         "Monthly Profit = Instalment Due (col O) − Subcontractor costs paid in month (col CW) − Clockify Billable Amount GBP (col S of Clockify)"),
        ("", "ALL THREE INPUTS ARE MONTHLY (in-period) figures. None of them is a running total."),
        ("", ""),
        ('Important note on "Cumulative Fee" (col P)',
         'In the Project Tracking template the column labelled "Cumulative Fee" is a running total of the fees billed up to and including that month within that project. It is shown in the detail sheet for context and reconciliation only — it is NOT used in the profitability calculation. The revenue input for profit is the Instalment Due (col O), which is the monthly figure for that period alone.'),
        ("", ""),
        ('"Profit to Date" columns',
         'Where "Profit to Date" / "Cumulative" Profit appears in this workbook, those are running sums of the Monthly Profit calculated by this analysis — they are not derived from col P. They are useful for spotting projects slowly drifting into loss.'),
        ("", ""),
        ("Project expenses (col Q) excluded",
         "Project Expenses are not included in this analysis. They are billed through to the client at cost (pass-through) and so are not a cost to the project. Excluded from both sides so profit reflects only the fee margin against actual delivery cost."),
        ("", ""),
        ("JGC_Company and JGC_Dev excluded",
         'All time and cost data for "JGC_Company" and "JGC_Dev" has been removed. These are internal-time / business-development codes (not client projects) and would distort the project-profitability picture.'),
        ("", ""),
        ("Data sources",
         "Project Tracking: every .xlsx file in the configured folder. Cols A, B, C, D, O, P, Q, CW are read."),
        ("",
         "Clockify_Export.xlsx: Project, Client, Duration (decimal), Billable, Billable Amount (GBP), Start Date."),
        ("", "Matched on Project Tracking col A (Project ID) ↔ Clockify col A (Project)."),
        ("", ""),
        ("Date filter", f"All data restricted to months ≤ {cutoff_str}, per configured cutoff."),
        ("", ""),
        ("Sheets", ""),
        ("Overview", "Headline metrics, yearly totals, Top/Bottom 10 projects."),
        ("Project Summary", "One row per project. Sorted by profit. Filterable."),
        ("Monthly Rollup", "Whole business by month with totals row and chart."),
        ("Yearly Rollup", "Whole business by year with totals row and chart."),
        ("Client Rollup", "Aggregated by client name. Useful for relationship reviews."),
        ("Profit Matrix (Monthly)",
         "Heat-map: projects (rows) × months (columns). Cells are monthly profit. Last column is project total."),
        ("Profit Matrix (Cumulative)",
         "Heat-map: running-sum profit-to-date at the end of each month per project. Computed by this analysis from monthly profits, NOT from col P."),
        ("Project-Month Detail", "Full long-format table for filtering / pivoting. Active months only."),
        ("", ""),
        ("Patterns to look for", ""),
        ("",
         "Profit Matrix (Monthly): red bands = months where time/subcon outran the instalment billed."),
        ("",
         'Project Summary "Avg Realised Rate (£/hr)" = (Instalments − Subcon) / hours — your effective hourly rate per project.'),
        ("", "Client Rollup: which clients are net-positive vs net-negative across all their work."),
        ("",
         "Monthly Rollup chart: any month where Clockify (orange) overtakes Instalments (blue) is a cashflow/working-capital warning."),
    ]
    for r, (a, b) in enumerate(readme_rows, start=3):
        ws.cell(row=r, column=1, value=a).font = BOLD_BODY if a and not a.startswith(" ") else BODY_FONT
        ws.cell(row=r, column=2, value=b).font = BODY_FONT
        ws.cell(row=r, column=2).alignment = Alignment(wrap_text=True, vertical="top")
    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 95

    # ---- Overview ------------------------------------------------------------
    ws = wb.create_sheet("Overview")
    ws["A1"] = "Project Profitability Analysis"
    ws["A1"].font = TITLE_FONT
    ws["A2"] = f"Combining Project Tracking files with Clockify time records — period: earliest data through {cutoff_str}"
    ws["A2"].font = SUBTITLE_FONT
    ws.cell(row=4, column=1, value="Headline metrics").font = SUBHDR_FONT

    monthly, yearly, proj = V["monthly"], V["yearly"], V["proj"]
    total_inst = monthly["Instalments (£)"].sum()
    total_subcon = monthly["Subcon (£)"].sum()
    total_clockify = monthly["Clockify Billable (£)"].sum()
    total_profit = total_inst - total_subcon - total_clockify
    total_hours = monthly["Clockify Hours"].sum()

    metrics = [
        ("Total instalments raised (col O)", total_inst, FMT_GBP),
        ("Total subcontractor costs in month (col CW)", total_subcon, FMT_GBP),
        ("Total Clockify billable time (col S)", total_clockify, FMT_GBP),
        ("Total Clockify hours", total_hours, FMT_HRS),
        ("Profitability (Instalments − Subcon − Time)", total_profit, FMT_GBP),
        ("Overall margin", (total_profit / total_inst * 100) if total_inst else 0, FMT_PCT_NUM),
        ("Active projects analysed", proj.shape[0], FMT_NUM),
        ("Projects in profit", int((proj["Profit (£)"] > 0).sum()), FMT_NUM),
        ("Projects at a loss", int((proj["Profit (£)"] < 0).sum()), FMT_NUM),
    ]
    r = 5
    for label, val, fmt in metrics:
        ws.cell(row=r, column=1, value=label).font = BODY_FONT
        c = ws.cell(row=r, column=2, value=val)
        c.font = BOLD_BODY; c.number_format = fmt; c.alignment = RIGHT
        if "Profit" in label or "margin" in label.lower():
            if isinstance(val, (int, float)):
                c.font = Font(name=FONT, size=10, bold=True,
                              color="C00000" if val < 0 else "006100")
        r += 1

    r += 1
    ws.cell(row=r, column=1, value="Profitability formula").font = SUBHDR_FONT
    r += 1
    ws.cell(row=r, column=1, value="Monthly Profit = Instalment Due (col O) − Subcontractor costs paid in month (col CW) − Clockify Billable Amount GBP (col S)").font = BODY_FONT
    r += 1
    ws.cell(row=r, column=1, value="All three inputs are MONTHLY (not cumulative). Project Expenses (col Q) and internal codes JGC_Company/JGC_Dev are excluded.").font = BODY_FONT

    # Yearly block
    r += 3
    ws.cell(row=r, column=1, value="Yearly totals").font = SUBHDR_FONT
    r += 1
    headers = ["Year", "Instalments (£)", "Subcon (£)", "Clockify (£)", "Hours", "Projects", "Profit (£)", "Margin"]
    for i, h in enumerate(headers, start=1):
        ws.cell(row=r, column=i, value=h)
    style_header_row(ws, r, len(headers))
    for _, yr in yearly.iterrows():
        r += 1
        vals = [int(yr["Year"]), yr["Instalments (£)"], yr["Subcon (£)"], yr["Clockify Billable (£)"],
                yr["Clockify Hours"], int(yr["Projects"]), yr["Profit (£)"],
                (yr["Margin %"] / 100 if pd.notna(yr["Margin %"]) else None)]
        fmts = ["0", FMT_GBP, FMT_GBP, FMT_GBP, FMT_HRS, FMT_NUM, FMT_GBP, FMT_PCT]
        for i, (v, fm) in enumerate(zip(vals, fmts), start=1):
            c = ws.cell(row=r, column=i, value=v)
            c.font = BODY_FONT; c.number_format = fm
            c.alignment = RIGHT if i > 1 else CENTER; c.border = BORDER_THIN

    # Top 10 / Bottom 10
    top_headers = ["Project ID", "Client", "Instalments (£)", "Subcon (£)", "Clockify (£)", "Hours", "Profit (£)", "Margin"]
    for title, slice_df in [("Top 10 most profitable projects", proj.head(10)),
                             ("Bottom 10 projects (largest losses)", proj.tail(10).iloc[::-1])]:
        r += 3
        ws.cell(row=r, column=1, value=title).font = SUBHDR_FONT
        r += 1
        for i, h in enumerate(top_headers, start=1):
            ws.cell(row=r, column=i, value=h)
        style_header_row(ws, r, len(top_headers))
        for _, row in slice_df.iterrows():
            r += 1
            vals = [row["Project ID"], row["Client"], row["Total Instalments (£)"], row["Total Subcon (£)"],
                    row["Total Clockify Billable (£)"], row["Total Clockify Hours"], row["Profit (£)"],
                    (row["Margin %"] / 100 if pd.notna(row["Margin %"]) else None)]
            fmts = ["@", "@", FMT_GBP, FMT_GBP, FMT_GBP, FMT_HRS, FMT_GBP, FMT_PCT]
            for i, (v, fm) in enumerate(zip(vals, fmts), start=1):
                c = ws.cell(row=r, column=i, value=v)
                c.font = BODY_FONT; c.number_format = fm
                c.alignment = RIGHT if i > 2 else LEFT; c.border = BORDER_THIN

    ws.column_dimensions["A"].width = 32
    ws.column_dimensions["B"].width = 40
    for col in "CDEFGH":
        ws.column_dimensions[col].width = 16
    ws.freeze_panes = "A4"

    # ---- Project Summary ----------------------------------------------------
    _write_summary_sheet(wb, "Project Summary", V["proj"],
                          subtitle="Sorted by total profit (descending). Profit = Instalment Due (col O) − Subcontractor (col CW) − Clockify Billable (col S). All monthly figures.",
                          colour_cols=["Profit (£)", "Margin %"],
                          alt_stripe=True, freeze="C5")

    # ---- Monthly Rollup -----------------------------------------------------
    _write_rollup_sheet(wb, "Monthly Rollup", V["monthly"],
                         title="Business totals by month",
                         subtitle="Aggregated across all projects.",
                         label_col="Month", revenue_col="Instalments (£)",
                         skip_total_cols={"Active Projects"},
                         chart_kind="line", chart_title="Monthly Instalments, Clockify Cost & Profit",
                         chart_series=["Instalments (£)", "Clockify Billable (£)", "Profit (£)"],
                         x_axis="Month")

    # ---- Yearly Rollup ------------------------------------------------------
    _write_rollup_sheet(wb, "Yearly Rollup", V["yearly"],
                         title="Business totals by year",
                         subtitle="",
                         label_col="Year", revenue_col="Instalments (£)",
                         skip_total_cols={"Projects"},
                         chart_kind="bar", chart_title="Yearly Instalments vs Clockify Cost vs Profit",
                         chart_series=["Instalments (£)", "Clockify Billable (£)", "Profit (£)"],
                         x_axis="Year")

    # ---- Client Rollup ------------------------------------------------------
    _write_summary_sheet(wb, "Client Rollup", V["client"],
                          subtitle="Sorted by total profit. Useful for relationship-level reviews.",
                          colour_cols=["Profit (£)"],
                          alt_stripe=True, freeze="B5")

    # ---- Profit Matrices ----------------------------------------------------
    _write_matrix_sheet(wb, "Profit Matrix (Monthly)", V["pivot_profit"],
                         title="Monthly profit per project (Fee − Subcon − Clockify, per month)",
                         subtitle="Rows: projects. Columns: months. Conditional formatting highlights gains vs losses.",
                         has_total=True)

    _write_matrix_sheet(wb, "Profit Matrix (Cumulative)", V["pivot_cumprofit"],
                         title="Cumulative profit-to-date per project, by month",
                         subtitle="Each cell = total Profit (Cum. Fee − Cum. Subcon − Cum. Clockify) at end of month. Blank = no data yet.",
                         has_total=False)

    # ---- Project-Month Detail -----------------------------------------------
    _write_detail_sheet(wb, V["detail"])

    # Save
    output_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(output_path)
    print(f"  Saved: {output_path}")


def _write_summary_sheet(wb, name, df, subtitle, colour_cols, alt_stripe=False, freeze=None):
    ws = wb.create_sheet(name)
    ws["A1"] = name
    ws["A1"].font = TITLE_FONT
    ws["A2"] = subtitle
    ws["A2"].font = SUBTITLE_FONT
    cols = list(df.columns)
    for i, h in enumerate(cols, start=1):
        ws.cell(row=4, column=i, value=h)
    style_header_row(ws, 4, len(cols))

    for r_idx, (_, row) in enumerate(df.iterrows(), start=5):
        for i, col in enumerate(cols, start=1):
            v = row[col]
            if pd.isna(v): v = None
            if isinstance(v, pd.Timestamp): v = v.to_pydatetime()
            c = ws.cell(row=r_idx, column=i, value=v)
            c.font = BODY_FONT; c.border = BORDER_THIN
            if col in MONEY_COLS:
                c.number_format = FMT_GBP; c.alignment = RIGHT
            elif col == "Margin %":
                c.number_format = FMT_PCT_NUM; c.alignment = RIGHT
            elif col == "Avg Realised Rate (£/hr)":
                c.number_format = FMT_GBP_DEC; c.alignment = RIGHT
            elif col in ("Total Clockify Hours", "Clockify Hours"):
                c.number_format = FMT_HRS; c.alignment = RIGHT
            elif col in ("First Month", "Last Active Month"):
                c.number_format = "yyyy-mm"; c.alignment = CENTER
            elif col == "# Projects":
                c.number_format = FMT_NUM; c.alignment = CENTER
            else:
                c.alignment = LEFT
        if alt_stripe and r_idx % 2 == 0:
            for i in range(1, len(cols) + 1):
                ws.cell(row=r_idx, column=i).fill = ALT_FILL

    last_row = 4 + len(df)
    for col_name in colour_cols:
        if col_name in cols:
            idx = cols.index(col_name) + 1
            letter = get_column_letter(idx)
            ws.conditional_formatting.add(
                f"{letter}5:{letter}{last_row}",
                ColorScaleRule(start_type="min", start_color="F8696B",
                               mid_type="num", mid_value=0, mid_color="FFEB84",
                               end_type="max", end_color="63BE7B")
            )
    autofit(ws, max_w=44)
    if freeze: ws.freeze_panes = freeze
    ws.auto_filter.ref = f"A4:{get_column_letter(len(cols))}{last_row}"


def _write_rollup_sheet(wb, name, df, title, subtitle, label_col, revenue_col,
                         skip_total_cols, chart_kind, chart_title, chart_series, x_axis):
    ws = wb.create_sheet(name)
    ws["A1"] = title
    ws["A1"].font = TITLE_FONT
    if subtitle:
        ws["A2"] = subtitle
        ws["A2"].font = SUBTITLE_FONT
    cols = list(df.columns)
    for i, h in enumerate(cols, start=1):
        ws.cell(row=4, column=i, value=h)
    style_header_row(ws, 4, len(cols))

    for r_idx, (_, row) in enumerate(df.iterrows(), start=5):
        for i, col in enumerate(cols, start=1):
            v = row[col]
            if pd.isna(v): v = None
            c = ws.cell(row=r_idx, column=i, value=v)
            c.font = BODY_FONT; c.border = BORDER_THIN
            if col in MONEY_COLS:
                c.number_format = FMT_GBP; c.alignment = RIGHT
            elif col == "Margin %":
                c.number_format = FMT_PCT_NUM; c.alignment = RIGHT
            elif col == "Clockify Hours":
                c.number_format = FMT_HRS; c.alignment = RIGHT
            elif col in ("Active Projects", "Projects"):
                c.number_format = FMT_NUM; c.alignment = CENTER
            elif col == "Year":
                c.number_format = "0"; c.alignment = CENTER
            else:
                c.alignment = CENTER

    # Totals row with formulas
    total_row = 5 + len(df)
    ws.cell(row=total_row, column=1, value="TOTAL").font = BOLD_BODY
    ws.cell(row=total_row, column=1).fill = TOTAL_FILL
    for i, col in enumerate(cols, start=1):
        if i == 1:
            continue
        letter = get_column_letter(i)
        if col == "Margin %":
            rev_col = get_column_letter(cols.index(revenue_col) + 1)
            profit_col = get_column_letter(cols.index("Profit (£)") + 1)
            ws.cell(row=total_row, column=i,
                    value=f"=IFERROR({profit_col}{total_row}/{rev_col}{total_row}*100,0)")
            ws.cell(row=total_row, column=i).number_format = FMT_PCT_NUM
        elif col == "Revenue / Hour (£)" and "Clockify Hours" in cols:
            rev_col = get_column_letter(cols.index(revenue_col) + 1)
            hrs_col = get_column_letter(cols.index("Clockify Hours") + 1)
            ws.cell(row=total_row, column=i,
                    value=f"=IFERROR({rev_col}{total_row}/{hrs_col}{total_row},0)")
            ws.cell(row=total_row, column=i).number_format = FMT_GBP
        elif col in skip_total_cols:
            ws.cell(row=total_row, column=i, value="")
        else:
            ws.cell(row=total_row, column=i, value=f"=SUM({letter}5:{letter}{total_row-1})")
            if col in MONEY_COLS:
                ws.cell(row=total_row, column=i).number_format = FMT_GBP
            elif col == "Clockify Hours":
                ws.cell(row=total_row, column=i).number_format = FMT_HRS
        ws.cell(row=total_row, column=i).font = BOLD_BODY
        ws.cell(row=total_row, column=i).fill = TOTAL_FILL
        ws.cell(row=total_row, column=i).border = BORDER_THIN
        ws.cell(row=total_row, column=i).alignment = RIGHT

    # Profit colour scale
    if "Profit (£)" in cols:
        pc = cols.index("Profit (£)") + 1
        pl = get_column_letter(pc)
        ws.conditional_formatting.add(
            f"{pl}5:{pl}{total_row-1}",
            ColorScaleRule(start_type="min", start_color="F8696B",
                           mid_type="num", mid_value=0, mid_color="FFEB84",
                           end_type="max", end_color="63BE7B")
        )

    autofit(ws, max_w=20)
    ws.freeze_panes = "B5"

    # Chart
    chart = LineChart() if chart_kind == "line" else BarChart()
    chart.title = chart_title
    chart.style = 2
    chart.height = 9 if chart_kind == "line" else 10
    chart.width = 22 if chart_kind == "line" else 18
    n = len(df)
    labels = Reference(ws, min_col=1, min_row=5, max_row=4 + n)
    for sname in chart_series:
        idx = cols.index(sname) + 1
        chart.add_data(Reference(ws, min_col=idx, min_row=4, max_row=4 + n), titles_from_data=True)
    chart.set_categories(labels)
    chart.y_axis.title = "GBP (£)"
    chart.x_axis.title = x_axis
    ws.add_chart(chart, f"{get_column_letter(len(cols) + 2)}4")


def _write_matrix_sheet(wb, name, df, title, subtitle, has_total):
    ws = wb.create_sheet(name)
    ws["A1"] = title
    ws["A1"].font = TITLE_FONT
    ws["A2"] = subtitle
    ws["A2"].font = SUBTITLE_FONT
    cols = list(df.columns)
    for i, h in enumerate(cols, start=1):
        ws.cell(row=4, column=i, value=h)
    style_header_row(ws, 4, len(cols))

    for r_idx, (_, row) in enumerate(df.iterrows(), start=5):
        for i, col in enumerate(cols, start=1):
            v = row[col]
            if pd.isna(v): v = None
            c = ws.cell(row=r_idx, column=i, value=v)
            c.font = BODY_FONT; c.border = BORDER_THIN
            if i <= 2:
                c.alignment = LEFT
            else:
                c.number_format = FMT_GBP; c.alignment = RIGHT

    last_row = 4 + len(df)
    last_col = len(cols)
    last_data_col = last_col - 1 if has_total else last_col
    data_range = f"{get_column_letter(3)}5:{get_column_letter(last_data_col)}{last_row}"
    ws.conditional_formatting.add(
        data_range,
        ColorScaleRule(start_type="min", start_color="F8696B",
                       mid_type="num", mid_value=0, mid_color="FFFFFF",
                       end_type="max", end_color="63BE7B")
    )
    if has_total:
        tl = get_column_letter(last_col)
        ws.conditional_formatting.add(
            f"{tl}5:{tl}{last_row}",
            ColorScaleRule(start_type="min", start_color="F8696B",
                           mid_type="num", mid_value=0, mid_color="FFEB84",
                           end_type="max", end_color="63BE7B")
        )

    ws.column_dimensions["A"].width = 14
    ws.column_dimensions["B"].width = 35
    for c in range(3, last_col + 1):
        ws.column_dimensions[get_column_letter(c)].width = 12
    ws.freeze_panes = "C5"
    ws.auto_filter.ref = f"A4:{get_column_letter(last_col)}{last_row}"


def _write_detail_sheet(wb, df):
    ws = wb.create_sheet("Project-Month Detail")
    ws["A1"] = "Project × Month detail (active months only)"
    ws["A1"].font = TITLE_FONT
    ws["A2"] = "One row per project per month where activity occurred. Monthly Profit = Instalment Due − Subcon − Clockify Billable (all monthly figures)."
    ws["A2"].font = SUBTITLE_FONT
    cols = list(df.columns)
    for i, h in enumerate(cols, start=1):
        ws.cell(row=4, column=i, value=h)
    style_header_row(ws, 4, len(cols))

    for r_idx, (_, row) in enumerate(df.iterrows(), start=5):
        for i, col in enumerate(cols, start=1):
            v = row[col]
            if pd.isna(v): v = None
            c = ws.cell(row=r_idx, column=i, value=v)
            c.font = BODY_FONT; c.border = BORDER_THIN
            if col in MONEY_COLS:
                c.number_format = FMT_GBP; c.alignment = RIGHT
            elif col == "Clockify Hours":
                c.number_format = FMT_HRS; c.alignment = RIGHT
            elif col == "Year":
                c.number_format = "0"; c.alignment = CENTER
            else:
                c.alignment = LEFT

    last_row = 4 + len(df)
    for col_name in ["Monthly Profit (£)", "Profit to Date (£)"]:
        if col_name in cols:
            idx = cols.index(col_name) + 1
            letter = get_column_letter(idx)
            ws.conditional_formatting.add(
                f"{letter}5:{letter}{last_row}",
                ColorScaleRule(start_type="min", start_color="F8696B",
                               mid_type="num", mid_value=0, mid_color="FFFFFF",
                               end_type="max", end_color="63BE7B")
            )

    widths = {"Project ID": 14, "Client": 35, "Month": 10, "Year": 8,
              "Instalment Due (£)": 14, "Cumulative Fee (£)": 16,
              "Subcontractor Costs (£)": 18, "Cum. Subcon (£)": 14,
              "Clockify Hours": 12, "Clockify Billable (£)": 16,
              "Cum. Clockify Billable (£)": 18, "Monthly Profit (£)": 15,
              "Profit to Date (£)": 15}
    for col_name, w in widths.items():
        if col_name in cols:
            ws.column_dimensions[get_column_letter(cols.index(col_name) + 1)].width = w
    ws.freeze_panes = "D5"
    ws.auto_filter.ref = f"A4:{get_column_letter(len(cols))}{last_row}"


# =============================================================================
# STEP 6 — write the HTML "Profit Ledger" dashboard
# =============================================================================

def _fy_start_year(d) -> int:
    """Given a date or datetime, return the financial year start (August–July)."""
    if hasattr(d, "month"):
        return d.year if d.month >= 8 else d.year - 1
    # Assume YYYY-MM string
    yr, mo = int(d[:4]), int(d[5:7])
    return yr if mo >= 8 else yr - 1


def _gbp(v: float) -> str:
    """Compact GBP formatter — £1.23m, £480k, £42."""
    sign = "−" if v < 0 else ""
    a = abs(v)
    if a >= 1e6:
        return sign + "£" + (f"{a/1e6:.2f}").rstrip("0").rstrip(".") + "m"
    if a >= 1e3:
        return sign + "£" + f"{a/1e3:.0f}" + "k"
    return sign + "£" + f"{round(a)}"


def build_html_data(combined: pd.DataFrame, cutoff: str,
                     df_cl: pd.DataFrame = None,
                     df_pt: pd.DataFrame = None,
                     excluded_engineers: list = None,
                     excluded_projects: list = None,
                     runway_starting_cash: float = None,
                     runway_burn_escalation: float = None,
                     runway_max_horizon_months: int = 84,
                     runway_monthly_burn: float = None,
                     profit_loss_path: str = None) -> dict:
    """Assemble the JSON payload the HTML template expects.

    If df_cl and excluded_engineers are provided, also computes the
    engineer-attribution analysis for Part VI.

    If df_pt and runway_starting_cash are provided, also computes the
    runway projection for Part VII.
    """
    # Annotate with FY
    combined = combined.copy()
    combined["year_month"] = combined["month"].dt.strftime("%Y-%m")
    combined["fy_start"] = combined["month"].apply(_fy_start_year)
    combined["fy_label"] = combined["fy_start"].apply(lambda y: f"{y}/{str(y+1)[-2:]}")

    # ---- Monthly series (for chart + heatmap) ----
    monthly_grp = combined.groupby("year_month").agg(
        instalments=("instalment_due", "sum"),
        subcon=("subcon_costs", "sum"),
        clockify=("clockify_billable_amount", "sum"),
        clockify_hours=("clockify_hours", "sum"),
    ).reset_index().sort_values("year_month")
    monthly_grp["profit"] = monthly_grp["instalments"] - monthly_grp["subcon"] - monthly_grp["clockify"]

    monthly_list = []
    for _, r in monthly_grp.iterrows():
        ym = r["year_month"]
        fy_s = _fy_start_year(ym)
        inst = float(r["instalments"])
        profit_v = float(r["profit"])
        margin_v = (profit_v / inst * 100) if inst > 0 else None
        monthly_list.append({
            "month": ym,
            "instalments": inst,
            "clockify": float(r["clockify"]),
            "subcon": float(r["subcon"]),
            "profit": profit_v,
            "hours": float(r["clockify_hours"]),
            "margin": margin_v,
            "fy_start": fy_s,
            "fy_label": f"{fy_s}/{str(fy_s+1)[-2:]}",
        })

    # ---- FY rollup ----
    fy_grp = combined.groupby("fy_start").agg(
        instalments=("instalment_due", "sum"),
        subcon=("subcon_costs", "sum"),
        clockify=("clockify_billable_amount", "sum"),
        clockify_hours=("clockify_hours", "sum"),
    ).reset_index().sort_values("fy_start")
    fy_grp["profit"] = fy_grp["instalments"] - fy_grp["subcon"] - fy_grp["clockify"]
    fy_grp["margin"] = np.where(
        fy_grp["instalments"] > 0,
        fy_grp["profit"] / fy_grp["instalments"] * 100,
        0,
    )
    # Months covered per FY
    months_per_fy = combined.groupby("fy_start")["month"].nunique().reset_index(name="months")
    fy_grp = fy_grp.merge(months_per_fy, on="fy_start", how="left")
    # Active projects per FY
    active = combined[
        (combined["instalment_due"] != 0)
        | (combined["subcon_costs"] != 0)
        | (combined["clockify_billable_amount"] != 0)
    ].groupby("fy_start")["project_id"].nunique().reset_index()
    active.columns = ["fy_start", "projects"]
    fy_grp = fy_grp.merge(active, on="fy_start", how="left").fillna(0)
    fy_grp["projects"] = fy_grp["projects"].astype(int)

    yearly_fy = []
    for _, r in fy_grp.iterrows():
        start = int(r["fy_start"])
        months = int(r["months"])
        yearly_fy.append({
            "fy": f"{start}/{str(start+1)[-2:]}",
            "fy_short": f"FY {start}/{str(start+1)[-2:]}",
            "months_covered": months,
            "partial": months < 12,
            "instalments": float(r["instalments"]),
            "subcon": float(r["subcon"]),
            "clockify": float(r["clockify"]),
            "hours": float(r["clockify_hours"]),
            "profit": float(r["profit"]),
            "margin": float(r["margin"]),
            "projects": int(r["projects"]),
        })

    # ---- Project summary (all projects, sorted by profit) ----
    proj_grp = combined.groupby("project_id").agg(
        client=("client", "last"),
        instalments=("instalment_due", "sum"),
        subcon=("subcon_costs", "sum"),
        clockify=("clockify_billable_amount", "sum"),
        hours=("clockify_hours", "sum"),
    ).reset_index()
    proj_grp["profit"] = proj_grp["instalments"] - proj_grp["subcon"] - proj_grp["clockify"]
    proj_grp["margin"] = np.where(
        proj_grp["instalments"] > 0,
        proj_grp["profit"] / proj_grp["instalments"] * 100,
        np.nan,
    )
    proj_grp = proj_grp.sort_values("profit", ascending=False).reset_index(drop=True)

    all_projects = []
    for _, r in proj_grp.iterrows():
        all_projects.append({
            "id": r["project_id"],
            "client": r["client"] or "",
            "instalments": float(r["instalments"]),
            "clockify": float(r["clockify"]),
            "hours": float(r["hours"]),
            "profit": float(r["profit"]),
            "margin": (float(r["margin"]) if pd.notna(r["margin"]) else None),
        })

    # ---- Project-month matrix (for time-window filtering in Part IV) ----
    # Sparse map: { project_id: { "YYYY-MM": [instalments, clockify, subcon, hours], ... } }
    # Used by the front-end to re-aggregate league tables to any time window.
    pm = combined.copy()
    pm["ym"] = pm["month"].dt.strftime("%Y-%m")
    project_month_matrix = {}
    for proj_id, group in pm.groupby("project_id"):
        cells = {}
        for _, r in group.iterrows():
            inst = float(r["instalment_due"])
            cl   = float(r["clockify_billable_amount"])
            sb   = float(r["subcon_costs"])
            hrs  = float(r["clockify_hours"])
            if inst != 0 or cl != 0 or sb != 0 or hrs != 0:
                cells[r["ym"]] = [round(inst, 2), round(cl, 2), round(sb, 2), round(hrs, 2)]
        if cells:
            project_month_matrix[proj_id] = cells

    all_months = sorted({m for proj in project_month_matrix.values() for m in proj.keys()})

    # ---- Top clients (12) ----
    client_grp = combined.groupby("client").agg(
        projects=("project_id", "nunique"),
        instalments=("instalment_due", "sum"),
        subcon=("subcon_costs", "sum"),
        clockify=("clockify_billable_amount", "sum"),
        hours=("clockify_hours", "sum"),
    ).reset_index()
    client_grp["profit"] = client_grp["instalments"] - client_grp["subcon"] - client_grp["clockify"]
    client_grp = client_grp.sort_values("profit", ascending=False).reset_index(drop=True)
    client_grp = client_grp[client_grp["client"].astype(str).str.strip() != ""]

    top_clients = []
    for _, r in client_grp.head(12).iterrows():
        top_clients.append({
            "client": r["client"],
            "projects": int(r["projects"]),
            "instalments": float(r["instalments"]),
            "clockify": float(r["clockify"]),
            "profit": float(r["profit"]),
            "margin": (float(r["profit"] / r["instalments"] * 100) if r["instalments"] > 0 else 0),
        })

    # ---- Headline metrics ----
    total_inst = float(monthly_grp["instalments"].sum())
    total_subcon = float(monthly_grp["subcon"].sum())
    total_clockify = float(monthly_grp["clockify"].sum())
    total_profit = total_inst - total_subcon - total_clockify
    total_hours = float(monthly_grp["clockify_hours"].sum())
    margin = (total_profit / total_inst * 100) if total_inst else 0

    payload = {
        "headlines": {
            "instalments": total_inst,
            "subcon": total_subcon,
            "clockify": total_clockify,
            "profit": total_profit,
            "margin": margin,
            "hours": total_hours,
            "projects_total": int(proj_grp.shape[0]),
            "projects_profit": int((proj_grp["profit"] > 0).sum()),
            "projects_loss": int((proj_grp["profit"] < 0).sum()),
        },
        "monthly": monthly_list,
        "yearly_fy": yearly_fy,
        "all_projects": all_projects,
        "project_month_matrix": project_month_matrix,
        "all_months": all_months,
        "top_clients": top_clients,
    }

    # ---- Engineer fee attribution (Part VI) ----
    if df_cl is not None and excluded_engineers is not None:
        payload["engineer_attribution"] = build_engineer_attribution(
            combined=combined,
            df_cl=df_cl,
            cutoff=cutoff,
            excluded_engineers=excluded_engineers,
            excluded_projects=excluded_projects or [],
        )

    # ---- Runway projection (Part VII) ----
    if df_pt is not None and runway_starting_cash is not None and runway_burn_escalation is not None:
        payload["runway"] = build_runway(
            combined=combined,
            df_pt=df_pt,
            cutoff=cutoff,
            starting_cash=runway_starting_cash,
            burn_escalation=runway_burn_escalation,
            excluded_projects=excluded_projects or [],
            max_horizon_months=runway_max_horizon_months,
            monthly_burn_override=runway_monthly_burn,
        )

    # ---- P&L comparatives (Part VIII) ----
    pl_comp = build_pl_comparatives(profit_loss_path)
    if pl_comp:
        payload["pl_comparatives"] = pl_comp

    return payload


def build_engineer_attribution(combined: pd.DataFrame, df_cl: pd.DataFrame,
                                cutoff: str, excluded_engineers: list,
                                excluded_projects: list) -> dict:
    """Allocate project fees across the top 4 engineers per (project, FY).

    For each project, in each financial year, identify the top 4 engineers
    by Clockify hours. Each receives a share of that (project, FY)'s
    instalment revenue in proportion to their hours within the credited set.
    Engineers ranked 5th or lower are not credited.

    Engineers listed in excluded_engineers are removed from the candidate
    pool entirely BEFORE the top-4 cut.
    """
    # Filter Clockify
    df = df_cl.copy()
    df = df[df["month"] <= cutoff]
    df = df[~df["User"].isin(excluded_engineers)]
    df = df[~df["Project"].isin(excluded_projects)]
    df["fy_start"] = df["Start Date"].apply(_fy_start_year)

    # Hours per (project, FY, engineer)
    hours = df.groupby(["Project", "fy_start", "User"])["Duration (decimal)"].sum().reset_index()
    hours.columns = ["project_id", "fy_start", "engineer", "hours"]
    hours = hours.sort_values(["project_id", "fy_start", "hours"],
                               ascending=[True, True, False])
    hours["rank"] = hours.groupby(["project_id", "fy_start"]).cumcount() + 1
    topN = hours[hours["rank"] <= 4].copy()

    # Share within each (project, FY)
    group_sum = topN.groupby(["project_id", "fy_start"])["hours"].transform("sum")
    topN["share"] = topN["hours"] / group_sum

    # Fee per (project, FY) from combined dataset
    fee_pf = combined.groupby(["project_id", "fy_start"])["instalment_due"].sum().reset_index()
    fee_pf.columns = ["project_id", "fy_start", "fee"]

    merged = topN.merge(fee_pf, on=["project_id", "fy_start"], how="left")
    merged["fee"] = merged["fee"].fillna(0)
    merged["attributed_fee"] = merged["share"] * merged["fee"]

    # Engineer × FY aggregation
    eng_fy = merged.groupby(["engineer", "fy_start"]).agg(
        attributed_fee=("attributed_fee", "sum"),
        hours=("hours", "sum"),
    ).reset_index()
    projects_per = merged.groupby(["engineer", "fy_start"])["project_id"].nunique().reset_index()
    projects_per.columns = ["engineer", "fy_start", "project_count"]
    eng_fy = eng_fy.merge(projects_per, on=["engineer", "fy_start"])

    # Per-engineer totals
    eng_total = eng_fy.groupby("engineer").agg(
        total_fee=("attributed_fee", "sum"),
        total_hours=("hours", "sum"),
    ).reset_index()
    proj_per_eng = merged.groupby("engineer")["project_id"].nunique().reset_index()
    proj_per_eng.columns = ["engineer", "total_projects"]
    eng_total = eng_total.merge(proj_per_eng, on="engineer")
    eng_total = eng_total.sort_values("total_fee", ascending=False)

    # All FYs that appear
    import numpy as np
    all_fys = sorted(eng_fy["fy_start"].unique().tolist())
    fy_list = [{"fy_start": int(y), "fy": f"{y}/{str(y+1)[-2:]}"} for y in all_fys]

    # Build per-engineer rows with FY values padded with zeroes
    engineers = []
    for _, r in eng_total.iterrows():
        eng_name = r["engineer"]
        sub = eng_fy[eng_fy["engineer"] == eng_name].set_index("fy_start")
        fy_values = []
        for y in all_fys:
            if y in sub.index:
                fy_values.append({
                    "fy_start": int(y),
                    "fy": f"{y}/{str(y+1)[-2:]}",
                    "fee": float(sub.loc[y, "attributed_fee"]),
                    "hours": float(sub.loc[y, "hours"]),
                    "projects": int(sub.loc[y, "project_count"]),
                })
            else:
                fy_values.append({
                    "fy_start": int(y),
                    "fy": f"{y}/{str(y+1)[-2:]}",
                    "fee": 0.0,
                    "hours": 0.0,
                    "projects": 0,
                })
        engineers.append({
            "name": eng_name,
            "total_fee": float(r["total_fee"]),
            "total_hours": float(r["total_hours"]),
            "total_projects": int(r["total_projects"]),
            "fy_values": fy_values,
        })

    total_attributed = float(merged["attributed_fee"].sum())
    total_fee = float(fee_pf["fee"].sum())

    return {
        "engineers": engineers,
        "fy_list": fy_list,
        "total_attributed": total_attributed,
        "total_fee": total_fee,
        "attribution_pct": (total_attributed / total_fee * 100) if total_fee else 0,
        "excluded_engineers": excluded_engineers,
    }


# =============================================================================
# PROFIT & LOSS COMPARATIVES (Part VIII) — read prior-FY turnover & profit
# from an accounting P&L export, if one is provided.
# =============================================================================
_PL_MON = {"jan":1,"feb":2,"mar":3,"apr":4,"may":5,"jun":6,"jul":7,
           "aug":8,"sep":9,"sept":9,"oct":10,"nov":11,"dec":12}

def _pl_num(v):
    return float(v) if isinstance(v, (int, float)) else 0.0

def _pl_parse_month_label(s):
    """'Jun 2026' / 'Sept 2025' -> (year, month) or None."""
    if not isinstance(s, str):
        return None
    parts = s.strip().split()
    if len(parts) != 2:
        return None
    mon = _PL_MON.get(parts[0].strip().lower().rstrip("."))
    try:
        yr = int(parts[1])
    except ValueError:
        return None
    return (yr, mon) if mon else None

def parse_pl_by_fy(pl_path):
    """Parse a Xero-style monthly P&L into per-FY (Aug-Jul) aggregates.

    Finds rows by label (Total Turnover / Total Cost of Sales /
    Total Administrative Costs / Operating Profit) so it is robust to the
    exact row positions. Returns {fy_start_year: {turnover, cos, admin, op, months}}.
    """
    from openpyxl import load_workbook
    wb = load_workbook(pl_path, read_only=True, data_only=True)
    ws = wb[wb.sheetnames[0]]
    rows = list(ws.iter_rows(values_only=True))
    header_idx = None
    for i, r in enumerate(rows):
        if r and isinstance(r[0], str) and r[0].strip().lower() == "account":
            header_idx = i
            break
    if header_idx is None:
        raise ValueError("P&L: could not find an 'Account' header row")
    header = rows[header_idx]
    col_month = {}
    for ci, cell in enumerate(header[1:], start=1):
        ym = _pl_parse_month_label(cell)
        if ym:
            col_month[ci] = ym

    def row_index(label):
        lab = label.strip().lower()
        for i, r in enumerate(rows):
            if r and isinstance(r[0], str) and r[0].strip().lower() == lab:
                return i
        return None

    def find_row(label):
        i = row_index(label)
        return rows[i] if i is not None else None

    def section_sum(header_label, total_label):
        """Sum the line-item rows that sit between a section header and its
        total row, per month column. Used as a fallback when the export's
        computed total rows have come through empty/zero (some P&L exports
        omit calculated subtotals)."""
        s = row_index(header_label)
        e = row_index(total_label)
        if s is None or e is None or e <= s:
            return None
        out = {ci: 0.0 for ci in col_month}
        for r in rows[s + 1:e]:
            for ci in col_month:
                if ci < len(r):
                    out[ci] += _pl_num(r[ci])
        return out

    def col_total(row):
        return sum(_pl_num(row[ci]) for ci in col_month if ci < len(row)) if row else 0.0

    r_turn  = find_row("Total Turnover")
    r_cos   = find_row("Total Cost of Sales")
    r_admin = find_row("Total Administrative Costs")
    r_op    = find_row("Operating Profit")
    if r_turn is None and row_index("Turnover") is None:
        raise ValueError("P&L: could not find a Turnover section")

    # Build per-column series for each measure. Prefer the export's own total
    # rows; if a total row is missing or sums to zero (totals not calculated in
    # this export), reconstruct it by summing the section's line items.
    def series(total_row, header_label, total_label):
        if total_row is not None and abs(col_total(total_row)) > 0.005:
            return {ci: _pl_num(total_row[ci]) for ci in col_month}
        summed = section_sum(header_label, total_label)
        if summed is not None:
            return summed
        return {ci: (_pl_num(total_row[ci]) if total_row else 0.0) for ci in col_month}

    turn_s  = series(r_turn,  "Turnover",             "Total Turnover")
    cos_s   = series(r_cos,   "Cost of Sales",        "Total Cost of Sales")
    admin_s = series(r_admin, "Administrative Costs", "Total Administrative Costs")
    # Operating profit: use its own row if populated, else Turnover − CoS − Admin.
    if r_op is not None and abs(col_total(r_op)) > 0.005:
        op_s = {ci: _pl_num(r_op[ci]) for ci in col_month}
    else:
        op_s = {ci: turn_s[ci] - cos_s[ci] - admin_s[ci] for ci in col_month}

    fy = {}
    for ci, (yr, mon) in col_month.items():
        fy_start = yr if mon >= 8 else yr - 1
        d = fy.setdefault(fy_start, dict(turnover=0.0, cos=0.0, admin=0.0, op=0.0, months=0))
        d["turnover"] += turn_s[ci]
        d["cos"]      += cos_s[ci]
        d["admin"]    += admin_s[ci]
        d["op"]       += op_s[ci]
        d["months"]   += 1
    return fy

def build_pl_comparatives(pl_path):
    """Return a sorted list of per-FY P&L figures for the dashboard.

    Each entry: {fy, fy_start, turnover, cost_of_sales, admin, operating_profit,
    margin, months, complete}. 'complete' means a full 12-month FY.
    Returns [] if the file is missing or unreadable (comparatives are optional).
    """
    from pathlib import Path as _Path
    if not pl_path or not _Path(pl_path).exists():
        return []
    try:
        fy = parse_pl_by_fy(pl_path)
    except Exception as exc:
        print(f"  Note: could not read P&L comparatives ({exc}). Skipping Part VIII comparatives.")
        return []
    out = []
    for sy in sorted(fy):
        d = fy[sy]
        turn = d["turnover"]
        out.append({
            "fy": f"{sy}/{str(sy+1)[-2:]}",
            "fy_start": int(sy),
            "turnover": float(turn),
            "cost_of_sales": float(d["cos"]),
            "admin": float(d["admin"]),
            "operating_profit": float(d["op"]),
            "margin": float(d["op"] / turn * 100) if turn else None,
            "months": int(d["months"]),
            "complete": bool(d["months"] >= 12),
        })
    return out



def build_runway(combined: pd.DataFrame, df_pt: pd.DataFrame, cutoff: str,
                  starting_cash: float, burn_escalation: float,
                  excluded_projects: list,
                  max_horizon_months: int = 84,
                  monthly_burn_override: float = None) -> dict:
    """Model cash runway from the cutoff date forward.

    Assumptions:
      - Every future instalment in the Project Tracking files lands in the
        month to which it is allocated.
      - No new work is won between now and insolvency.
      - The monthly cost base holds at this FY's average and escalates by
        `burn_escalation` (e.g. 0.10 for 10%) at each FY boundary thereafter.
      - Starting cash on hand at the cutoff date is `starting_cash`.

    Returns a dict suitable for the HTML dashboard.
    """
    from dateutil.relativedelta import relativedelta

    cutoff_dt = pd.Timestamp(cutoff)

    # ---- Current FY monthly burn rate ----
    combined = combined.copy()
    combined["fy_start"] = pd.to_datetime(combined["month"]).apply(_fy_start_year)
    current_fy = _fy_start_year(cutoff_dt)
    cfy_rows = combined[combined["fy_start"] == current_fy]
    months_in_cfy = cfy_rows["month"].dt.strftime("%Y-%m").nunique()
    if months_in_cfy == 0:
        # Fallback: no data in current FY — use the last available FY
        current_fy = combined["fy_start"].max()
        cfy_rows = combined[combined["fy_start"] == current_fy]
        months_in_cfy = cfy_rows["month"].dt.strftime("%Y-%m").nunique()

    total_cost_cfy = float(cfy_rows["subcon_costs"].sum() + cfy_rows["clockify_billable_amount"].sum())
    auto_monthly_burn = total_cost_cfy / months_in_cfy if months_in_cfy else 0
    # The auto value (current-FY average cost) is the default. If a manual burn
    # rate has been configured, it overrides the default for the forward
    # projection. The auto value is always passed to the dashboard as a reference,
    # and the historical overlays below always use their own anchor-derived burn.
    burn_is_manual = monthly_burn_override is not None
    monthly_burn = float(monthly_burn_override) if burn_is_manual else auto_monthly_burn

    # ---- Future fees from Project Tracking ----
    future = df_pt[(df_pt["month"] > cutoff_dt) & (df_pt["instalment_due"] > 0)].copy()
    future = future[~future["project_id"].isin(excluded_projects)]
    future_fees = future.groupby("month")["instalment_due"].sum().to_dict()
    total_future_fees = float(sum(future_fees.values()))

    # ---- Walk forward month-by-month ----
    def burn_for_fy(fy):
        years_past = fy - current_fy
        return monthly_burn * ((1 + burn_escalation) ** max(0, years_past))

    start_month = (cutoff_dt + relativedelta(months=1)).replace(day=1)
    projection = []
    runway_end = None
    peak = {"month": cutoff_dt, "cash_end": starting_cash}

    cash = starting_cash
    month = pd.Timestamp(start_month)
    for _ in range(max_horizon_months):
        fee = float(future_fees.get(month, 0))
        fy = _fy_start_year(month)
        burn = burn_for_fy(fy)
        net = fee - burn
        new_cash = cash + net
        projection.append({
            "month": month.strftime("%Y-%m"),
            "fee": float(fee),
            "burn": float(burn),
            "net": float(net),
            "cash_end": float(new_cash),
            "fy_start": int(fy),
            "fy_label": f"{fy}/{str(fy+1)[-2:]}",
        })
        if runway_end is None and new_cash < 0:
            runway_end = month
        if new_cash > peak["cash_end"]:
            peak = {"month": month, "cash_end": new_cash}
        cash = new_cash
        month = month + relativedelta(months=1)
        if cash < -1_000_000:
            break

    # ---- Trim projection to 6 months past runway end (for chart clarity) ----
    if runway_end is not None:
        end_idx = next((i for i, p in enumerate(projection)
                        if p["month"] == runway_end.strftime("%Y-%m")), None)
        if end_idx is not None:
            projection = projection[:end_idx + 7]

    # ---- Per-FY burn schedule (for the assumption table) ----
    burn_per_fy = {}
    for p in projection:
        if p["fy_start"] not in burn_per_fy:
            burn_per_fy[p["fy_start"]] = p["burn"]
    burn_table = [
        {"fy_start": int(fy), "fy": f"{fy}/{str(fy+1)[-2:]}", "monthly_burn": float(v)}
        for fy, v in sorted(burn_per_fy.items())
    ]

    # ---- Runway length in months ----
    if runway_end is not None:
        rw_months = (runway_end.year - cutoff_dt.year) * 12 + (runway_end.month - cutoff_dt.month)
        runway_end_str = runway_end.strftime("%B %Y")
    else:
        rw_months = None
        runway_end_str = None

    # ----------------------------------------------------------------
    # Historical comparison projections — same logic, anchored 1yr and
    # 2yr ago. We compute the projection line only (not the full payload).
    # ----------------------------------------------------------------
    historical = {}
    for years_back in (1, 2):
        hist_cutoff = cutoff_dt - relativedelta(years=years_back)
        hist_label = f"{years_back}y_ago"

        # Reconstruct what "current FY" meant at that point
        hist_current_fy = _fy_start_year(hist_cutoff)
        hist_cfy_rows = combined[
            (combined["fy_start"] == hist_current_fy)
            & (combined["month"] <= hist_cutoff)
        ]
        hist_months_in_cfy = hist_cfy_rows["month"].dt.strftime("%Y-%m").nunique()
        if hist_months_in_cfy == 0:
            # No data in that FY (e.g. anchor predates the data window) — skip
            historical[hist_label] = None
            continue

        hist_total_cost = float(
            hist_cfy_rows["subcon_costs"].sum()
            + hist_cfy_rows["clockify_billable_amount"].sum()
        )
        hist_monthly_burn = hist_total_cost / hist_months_in_cfy

        # Future fees: instalments booked into months AFTER the historical anchor
        # (this includes fees that have since landed in months between the anchor
        # and now — they were already in the schedule at the anchor date)
        hist_future = df_pt[
            (df_pt["month"] > hist_cutoff) & (df_pt["instalment_due"] > 0)
        ].copy()
        hist_future = hist_future[~hist_future["project_id"].isin(excluded_projects)]
        hist_future_fees = hist_future.groupby("month")["instalment_due"].sum().to_dict()

        # Burn function for historical anchor
        def hist_burn_for_fy(fy, base=hist_monthly_burn, current=hist_current_fy):
            years_past = fy - current
            return base * ((1 + burn_escalation) ** max(0, years_past))

        # We DO NOT bake a starting cash into the historical projection — the user
        # controls it via the UI. We pass cumulative net change (delta from starting
        # cash) so the JS can simply add their chosen starting cash.
        hist_start_month = (hist_cutoff + relativedelta(months=1)).replace(day=1)
        hist_projection = []
        cumulative_delta = 0.0
        h_month = pd.Timestamp(hist_start_month)
        for _ in range(max_horizon_months):
            fee = float(hist_future_fees.get(h_month, 0))
            fy = _fy_start_year(h_month)
            burn = hist_burn_for_fy(fy)
            net = fee - burn
            cumulative_delta += net
            hist_projection.append({
                "month": h_month.strftime("%Y-%m"),
                "fee": fee,
                "burn": float(burn),
                "net": float(net),
                "cumulative_delta": float(cumulative_delta),
                "fy_start": int(fy),
            })
            h_month = h_month + relativedelta(months=1)
            # Stop a bit past where the line will plausibly cross zero with sensible
            # starting cash; we cap at max_horizon_months anyway.
            if cumulative_delta < -2_000_000:
                break

        historical[hist_label] = {
            "anchor_cutoff": str(hist_cutoff.date()),
            "anchor_label": hist_cutoff.strftime("%B %Y"),
            "current_fy_label": f"{hist_current_fy}/{str(hist_current_fy+1)[-2:]}",
            "months_in_current_fy": int(hist_months_in_cfy),
            "monthly_burn": float(hist_monthly_burn),
            "start_month": hist_start_month.strftime("%Y-%m"),
            "projection": hist_projection,
        }

    return {
        "starting_cash": float(starting_cash),
        "monthly_burn_current_fy": float(monthly_burn),
        "auto_monthly_burn": float(auto_monthly_burn),
        "burn_is_manual": bool(burn_is_manual),
        "burn_escalation_pct": float(burn_escalation * 100),
        "cutoff": str(cutoff_dt.date()),
        "cutoff_label": cutoff_dt.strftime("%B %Y"),
        "months_in_current_fy": int(months_in_cfy),
        "current_fy_label": f"{current_fy}/{str(current_fy+1)[-2:]}",
        "current_fy_start": int(current_fy),
        "start_month": start_month.strftime("%Y-%m"),
        "max_horizon_months": int(max_horizon_months),
        "future_fees_by_month": {
            m.strftime("%Y-%m"): float(v) for m, v in sorted(future_fees.items())
        },
        "projection": projection,
        "runway_months": rw_months,
        "runway_end": runway_end_str,
        "peak_cash": float(peak["cash_end"]),
        "peak_month": peak["month"].strftime("%Y-%m") if hasattr(peak["month"], "strftime") else str(peak["month"]),
        "total_future_fees": total_future_fees,
        "burn_per_fy": burn_table,
        "historical": historical,
    }


def write_html_ledger(combined: pd.DataFrame, template_path: Path,
                      output_path: Path, cutoff: str,
                      df_cl: pd.DataFrame = None,
                      df_pt: pd.DataFrame = None,
                      excluded_engineers: list = None,
                      excluded_projects: list = None,
                      runway_starting_cash: float = None,
                      runway_burn_escalation: float = None,
                      runway_max_horizon_months: int = 84,
                      runway_monthly_burn: float = None,
                      profit_loss_path: str = None):
    """Render the Profit Ledger HTML by stitching data into the template."""
    if not template_path.exists():
        raise FileNotFoundError(
            f"HTML template not found at {template_path}. "
            "Make sure ledger_template.html sits alongside this script."
        )

    data = build_html_data(combined, cutoff,
                            df_cl=df_cl,
                            df_pt=df_pt,
                            excluded_engineers=excluded_engineers,
                            excluded_projects=excluded_projects,
                            runway_starting_cash=runway_starting_cash,
                            runway_burn_escalation=runway_burn_escalation,
                            runway_max_horizon_months=runway_max_horizon_months,
                            runway_monthly_burn=runway_monthly_burn,
                            profit_loss_path=profit_loss_path)
    html = template_path.read_text(encoding="utf-8")

    # ---- Compose replacements ----
    h = data["headlines"]
    cutoff_dt = datetime.strptime(cutoff, "%Y-%m-%d")
    masthead_date = cutoff_dt.strftime("%B %Y")

    earliest = min(m["month"] for m in data["monthly"])
    earliest_dt = datetime.strptime(earliest + "-01", "%Y-%m-%d")
    earliest_str = earliest_dt.strftime("%B %Y")
    period_str = f"{earliest_str} — {masthead_date}"

    # Margin formatted to 1dp
    margin_str = f"{h['margin']:+.1f}%".replace("+", "")  # plain "24.3%"
    # Hours rounded with comma separators
    hours_str = f"{round(h['hours']):,}"

    fy_count_words = {1: "one", 2: "two", 3: "three", 4: "four", 5: "five",
                      6: "six", 7: "seven", 8: "eight"}
    fy_count = len(data["yearly_fy"])
    fy_count_str = fy_count_words.get(fy_count, str(fy_count))

    replacements = {
        "__DATA_PLACEHOLDER__": json.dumps(data, separators=(",", ":")),
        "__KPI_INSTALMENTS__": _format_kpi_money(h["instalments"]),
        "__KPI_SUBCON__": _format_kpi_money(h["subcon"]),
        "__KPI_TIME__": _format_kpi_money(h["clockify"]),
        "__KPI_HOURS__": hours_str,
        "__KPI_PROFIT__": _format_kpi_money(h["profit"]),
        "__KPI_MARGIN__": margin_str,
        "__KPI_PROJECTS__": str(h["projects_total"]),
        "__KPI_IN_PROFIT__": str(h["projects_profit"]),
        "__KPI_AT_LOSS__": str(h["projects_loss"]),
        "__MASTHEAD_DATE__": masthead_date,
        "__STANDFIRST_PROJECTS__": str(h["projects_total"]),
        "__STANDFIRST_FY_COUNT__": fy_count_str,
        "__COLOPHON_COMPILED__": datetime.now().strftime("%B %Y"),
        "__COLOPHON_PERIOD__": period_str,
    }

    # Sanity-check that every placeholder in the template is being filled
    template_placeholders = set(re.findall(r"__[A-Z_]+__", html))
    provided = set(replacements.keys())
    missing = template_placeholders - provided
    if missing:
        raise RuntimeError(f"Template has unfilled placeholders: {missing}")
    extra = provided - template_placeholders
    if extra:
        # Not fatal but worth knowing about
        print(f"  Note: replacements provided that aren't in the template: {extra}")

    for placeholder, value in replacements.items():
        html = html.replace(placeholder, value)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(html, encoding="utf-8")
    print(f"  Saved: {output_path}")


def _format_kpi_money(v: float) -> str:
    """Format a money KPI for the large display cards.
    Produces HTML like '£1.23<span class="pence">m</span>' to match the template.
    """
    sign = "−" if v < 0 else ""
    a = abs(v)
    if a >= 1e6:
        whole = f"{a/1e6:.2f}"
        return f'{sign}£{whole}<span class="pence">m</span>'
    if a >= 1e3:
        whole = f"{a/1e3:.0f}"
        return f'{sign}£{whole}<span class="pence">k</span>'
    return f"{sign}£{round(a)}"


# =============================================================================
# MAIN
# =============================================================================

def _auto_detect_cutoff(clockify_path):
    """If the config has no cutoff date, default to the end of the most recent
    COMPLETED month in the Clockify data.

    The latest month present is treated as complete only if its last entry
    falls within 3 days of that month's end (time is typically logged through
    the final working days). Otherwise the month is considered in-progress and
    the cutoff rolls back to the previous month-end — so a fresh export taken
    a few days into a new month doesn't drag a partial month into the
    analysis. Pin cutoff_month_end in config.json to override.
    """
    df = pd.read_excel(clockify_path)
    df["Start Date"] = pd.to_datetime(df["Start Date"])
    latest = df["Start Date"].max()
    if latest is pd.NaT:
        raise SystemExit("ERROR: Clockify export contains no dated entries.")
    latest_month_end = (latest.replace(day=1) + pd.offsets.MonthEnd(0))
    if (latest_month_end - latest).days <= 3:
        cutoff = latest_month_end                      # month effectively complete
    else:
        cutoff = (latest.replace(day=1) - pd.offsets.MonthEnd(1))  # previous month-end
    return cutoff.strftime("%Y-%m-%d")


def _archive_outputs(excel_path, html_path, archive_folder, cutoff_str):
    """Copy outputs into a dated archive subfolder for permanent record-keeping."""
    if not archive_folder:
        return
    archive_folder = Path(archive_folder)
    # Use the cutoff date as the folder name
    folder = archive_folder / cutoff_str
    folder.mkdir(parents=True, exist_ok=True)
    import shutil
    archived = []
    for src in [excel_path, html_path]:
        if src and Path(src).exists():
            dest = folder / Path(src).name
            shutil.copy2(src, dest)
            archived.append(dest)
    if archived:
        print(f"\n  Archived to:")
        for a in archived:
            print(f"    {a}")


def main():
    print("=" * 70)
    print("PROJECT PROFITABILITY ANALYSIS")
    print("=" * 70)
    print(f"  Package root: {_CFG['ROOT']}")

    # Sanity-check paths
    if not PROJECT_TRACKING_FOLDER.exists():
        raise SystemExit(
            f"\nERROR: Project Tracking folder not found.\n"
            f"  Expected at: {PROJECT_TRACKING_FOLDER}\n\n"
            f"This folder should contain one .xlsx file per project. "
            f"Drop your Project Tracking files into:\n  {PROJECT_TRACKING_FOLDER}"
        )
    if not CLOCKIFY_EXPORT_PATH.exists():
        raise SystemExit(
            f"\nERROR: Clockify export not found.\n"
            f"  Expected at: {CLOCKIFY_EXPORT_PATH}\n\n"
            f"Export the latest 'Detailed Report' from Clockify as an .xlsx "
            f"and save it (overwriting any previous copy) at the path above."
        )
    if HTML_OUTPUT_PATH is not None and not HTML_TEMPLATE_PATH.exists():
        raise SystemExit(
            f"\nERROR: HTML template not found.\n"
            f"  Expected at: {HTML_TEMPLATE_PATH}\n\n"
            f"This file came with the package and shouldn't have been moved. "
            f"Re-extract the package or set html_output to false in config.json "
            f"to skip the HTML output."
        )

    # Resolve cutoff: explicit in config, or auto-detect
    cutoff = CUTOFF_MONTH_END
    if not cutoff:
        cutoff = _auto_detect_cutoff(CLOCKIFY_EXPORT_PATH)
        print(f"  Cutoff auto-detected from data: {cutoff}")
    else:
        print(f"  Cutoff (from config):           {cutoff}")

    print(f"\n  Project Tracking folder: {PROJECT_TRACKING_FOLDER}")
    print(f"  Clockify export:         {CLOCKIFY_EXPORT_PATH}")
    print(f"  Excluded projects:       {EXCLUDED_PROJECTS}")
    print(f"  Excluded engineers:      {EXCLUDED_ENGINEERS}")
    print(f"  Runway starting cash:    £{RUNWAY_STARTING_CASH:,.0f}")
    print(f"  Runway burn escalation:  +{RUNWAY_BURN_ESCALATION*100:.0f}% per FY")
    print(f"  Excel output:            {OUTPUT_PATH}")
    if HTML_OUTPUT_PATH is not None:
        print(f"  HTML output:             {HTML_OUTPUT_PATH}")

    total_steps = 6 if HTML_OUTPUT_PATH is not None else 5

    # Ensure output folders exist
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    if HTML_OUTPUT_PATH is not None:
        HTML_OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)

    print(f"\nStep 1/{total_steps}: Reading Project Tracking files...")
    df_pt = extract_project_tracking(PROJECT_TRACKING_FOLDER)

    print(f"\nStep 2/{total_steps}: Reading Clockify export...")
    df_cl = extract_clockify(CLOCKIFY_EXPORT_PATH, cutoff)

    print(f"\nStep 3/{total_steps}: Merging sources...")
    combined = merge_sources(df_pt, df_cl, cutoff, EXCLUDED_PROJECTS)

    print(f"\nStep 4/{total_steps}: Building views...")
    views = build_views(combined)

    print(f"\nStep 5/{total_steps}: Writing Excel workbook...")
    write_workbook(views, OUTPUT_PATH, cutoff)

    if HTML_OUTPUT_PATH is not None:
        print(f"\nStep 6/{total_steps}: Writing HTML ledger...")
        write_html_ledger(combined, HTML_TEMPLATE_PATH, HTML_OUTPUT_PATH,
                           cutoff,
                           df_cl=df_cl,
                           df_pt=df_pt,
                           excluded_engineers=EXCLUDED_ENGINEERS,
                           excluded_projects=EXCLUDED_PROJECTS,
                           runway_starting_cash=RUNWAY_STARTING_CASH,
                           runway_burn_escalation=RUNWAY_BURN_ESCALATION,
                           runway_max_horizon_months=RUNWAY_MAX_HORIZON_MONTHS,
                           runway_monthly_burn=RUNWAY_MONTHLY_BURN,
                           profit_loss_path=str(PROFIT_LOSS_PATH) if PROFIT_LOSS_PATH else None)

    # Headline summary to stdout
    monthly = views["monthly"]
    proj = views["proj"]
    total_inst = monthly["Instalments (£)"].sum()
    total_subcon = monthly["Subcon (£)"].sum()
    total_clockify = monthly["Clockify Billable (£)"].sum()
    total_profit = total_inst - total_subcon - total_clockify
    margin = (total_profit / total_inst * 100) if total_inst else 0

    print("\n" + "=" * 70)
    print("HEADLINE FIGURES")
    print("=" * 70)
    print(f"  Total instalments raised:     £{total_inst:>14,.2f}")
    print(f"  Total subcontractor costs:    £{total_subcon:>14,.2f}")
    print(f"  Total Clockify billable time: £{total_clockify:>14,.2f}")
    print(f"  -----------------------------------------------")
    print(f"  Profit:                       £{total_profit:>14,.2f}")
    print(f"  Margin:                        {margin:>14.2f}%")
    print(f"  Projects in profit / loss:    {(proj['Profit (£)']>0).sum():>5} / {(proj['Profit (£)']<0).sum():<5}")

    # Archive a copy
    if ARCHIVE_OUTPUTS:
        _archive_outputs(OUTPUT_PATH, HTML_OUTPUT_PATH, ARCHIVE_FOLDER, cutoff)

    print("=" * 70)
    print("Done. Open the HTML ledger by double-clicking:")
    print(f"  {HTML_OUTPUT_PATH}")
    print("=" * 70)


if __name__ == "__main__":
    main()
