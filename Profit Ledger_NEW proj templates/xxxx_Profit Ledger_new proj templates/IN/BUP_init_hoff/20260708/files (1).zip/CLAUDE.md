# CLAUDE.md — Profit Ledger Project

Read first in any new session. Current as of 5 July 2026 (data through 30 June 2026).

## What this is
Monthly profitability pipeline for **JGC Engineers** (architecture/engineering, Cambridge colleges). Inputs: ~199 Project Tracking `.xlsx` + Clockify export + optional accounting P&L. Outputs: `Profit_Ledger.html` (interactive broadsheet dashboard, 8 sections) + `Project_Profitability_Analysis.xlsx` (9 sheets). Shipped as self-contained `profit_ledger.zip` (24 files; includes novice SETUP_AND_OPERATION_GUIDE.md). User DanO re-runs monthly. FY = **Aug–Jul**.

## Locked methodology — NEVER change without instruction
- **Monthly Profit = Instalment Due (col O) − Subcontractor (col CW) − Clockify Billable GBP (col S)**, in-period.
- Col P context only; col Q excluded; `JGC_Company`/`JGC_Dev` excluded; `Dan`/`Pelifa French` excluded from attribution.
- PT → one row per project-month BEFORE Clockify merge.
- **Attribution: top FOUR by hours per (project, FY)**, fee ∝ hours, 5th+ uncredited.
- Engagements = union PT + Clockify-only IDs; zero-activity counts as neither.
- **Cutoff auto-detect** = most recent COMPLETED month (last entry within 3 days of month-end, else prior month-end). Override `cutoff_month_end`.
- **Burn rule**: P&L CoS + Admin averaged over COMPLETE, NORMAL current-FY months; "Outside P+L Tracking" excluded; partial-posted months excluded; anomalous one-offs excluded with judgment flagged.

## Source layout — DUAL FORMAT (auto-detected per file, since 5 Jul rewrite)
**NEW** — 'Project Definition' sheet (`001.XXXX_NN.xlsx` template files): metadata hdr row 2 / values row 3 (**B=Job Code → project_id, O=Client**); monthly table hdr row 8, data row 9+ (**G=Month**; instalment = Σ Fee1..12inMonth, subcon = Σ SubconCost1..5inMonth, expenses = Σ ExpensesType1..3inMonth; columns resolved BY HEADER NAME with canonical fallback). **Total columns (BD/BO/BW/BY) are uncached formulas in template-generated files — NEVER rely on them; sum components** (hard-typed total used only if components empty). Cumulative fee = computed running cumsum (matches legacy col P). One row per month incl. zero months.
**LEGACY** — 'Monthly' sheet: data row 4+; A=Project ID, B=Month, D=Client, O=Instalment, CW=Subcon — still supported; mixed folders fine (never same project in both formats — double-counts).
Skip `20260`/`001_`/`~`, applied AFTER stripping a `NNN.` sequencing prefix (catches `001.001_Resource.xlsx`) + post-read Job Code check. Clockify: Project/User/Start Date/Billable Amount (GBP)/Duration (decimal). P&L parsed by row label; **parser falls back to summing section line items when subtotal rows are blank/zero** (some exports omit calculated totals).

## Canonical copies — CRITICAL
Template regression is the #1 failure. After EVERY template edit sync: standalone working copy, `profit_ledger_dist/src/ledger_template.html`, `/mnt/user-data/outputs/ledger_template.html`. Engines likewise (packaged `run_analysis.py` / standalone `run_monthly_analysis.py`). **Playwright-validate after every template change. Test from fresh unzip.**

## Dashboard
KPI row · I trend+brush · II FY table (abs/% toggle; **Rev/hr** column, stays a rate in % view, weighted total) · III heatmap · IV league tables + time window · V clients · VI team (top-4) · VII runway (absolute £/mo burn + auto-proxy reference; £550k cash; escalator; new work; 2 historical inputs; 1y/2y overlays) · VIII year in prospect (live projection + P&L comparison; shows up to 2 complete prior FYs — currently one, FY 2023/24 being a 2-month partial in the P&L window).

## Config (current values)
`runway_starting_cash: 550000` · `runway_monthly_burn: 87467` (manual; June 2026 wage spike £128k vs £66k norm excluded as catch-up accrual — if genuinely recurring, switch to 94361) · `runway_burn_escalation: 0.10` · `profit_loss_path: "data/Profit_and_Loss.xlsx"` (kept OUT of zip) · stop-loss **−£1,000,000**; runway counts crossing month. Auto-proxy currently £89,345.

## Engineering lessons
- **New-format migration validated 5 Jul**: legacy reader on 200 original files vs new reader on 200 mapped files — instalments £7,251,424.71 and subcon £639,420.90 reconcile EXACTLY per project-month; dashboards identical except 3 deliberate client renames in new data (ELYC_01→formal Ely Cathedral name, HARL_01→PCC prefix, WLV_01 Milton Keynes Council→TOWN (Wolverton)). Internal Job Codes match legacy col-A IDs (AC_ filename prefix never was the internal ID) → Clockify merge unaffected. Old-format expense col Q (£7,832.90, excluded from profit anyway) not carried to new expense cols — chargeable expenses sit in subcon lines, matching legacy CW.
- New files carry longer zero-month tails (144 vs 123 rows) — all zero-activity, filtered by cutoff; harmless.
- monthly_list entries need hours+margin. No getElementById on innerHTML-destroyed nodes. `.bat` CRLF, `.sh` LF+exec.
- Workspace resets between sessions — rebuild from outputs zip; uploads persist within session.
- **Clockify exports can grow backwards** (Sep-2020 tail appeared June: +£39k time, profit −£41k). Check min/max dates each refresh.
- **P&L exports get revised AND change format** — recompute burn every update; the 5-Jul export shipped with all subtotal rows zeroed (parser fallback now handles it; FY24/25 reconciles exactly £1,339,111/£313,376).
- Top-3→top-4 left attribution totals identical (fee fully attributed wherever ≥1 engineer credited).
- Burn completeness: "COS>0" insufficient — judge against normal monthly range.

## Current state (cutoff 30 June 2026; engine rewritten 5 Jul for new source format)
Engine now reads BOTH PT layouts (see Source layout). Parity-tested + cold-tested from fresh unzip against the manual mapping set with a synthetic Clockify export; production figures below are from the last real-data run (legacy format) and should be regenerated on the next monthly run with the real Clockify + new-format files.
£5.31m instalments · £501k subcon · £3.65m time (61,262 hrs) · **profit £1,151,863 / margin 21.71%** · 214 engagements (151/61) · runway **19mo → Jan 2028**, peak £759,768 · Part VIII: projected FY25/26 £1,416,627 turnover / £367,023 profit (25.9%) vs FY24/25 £1,339,111/£313,376 (23.4%) · **Rev/hr declining £119→£76 across six FYs** · package rebuilt + cold-tested 5 Jul.

## Deferred / pending
- **User to confirm**: June £128k wages one-off (burn stays 87467) vs permanent (→ 94361).
- Stale NOTES section at dashboard bottom — refresh on request.
- Auto-burn-from-P&L each run — offered, not requested.
- FY closes 31 July: next run rolls the FY; comparatives then show two complete priors again.

## Conventions
Deliver via present_files; keep outputs/ artefacts synced. Transcripts `/mnt/transcripts/` (journal.txt) — read incrementally. Legacy Power BI files superseded. **Design system is strict — user style contract, apply to ALL HTML/visual outputs:** "financial analysis dashboard... refined editorial / financial-broadsheet aesthetic — Financial Times or Bloomberg Terminal sensibility: serif headlines, restrained palette (cream/off-white background, ink-black text, single accent colour), generous typography, asymmetric grid, dense but readable... No purple gradients, no glassmorphism. Single page, dark navy + cream + a muted oxblood accent for negatives/highlights." Also: clear concise analysis, well laid out, appropriate graphics + user controls. Locked tokens: cream `#f5efe2` / ink navy `#0e1e2e` / oxblood `#7a2326`; Source Serif 4 / Spectral / JetBrains Mono; no sans/icons/gradients/glass/dark. British English; minus `−`. Codified in DESIGN_SYSTEM.md.
