# PROFIT LEDGER — Setup & Operation Guide (for first-time users)

This guide assumes no technical background. It walks you through setting up the
program on your PC, where to put your data files each month, and how to run the
analysis. Ten minutes the first time; two minutes a month thereafter.

For deeper reference material (the methodology, every config setting, dashboard
features, troubleshooting), see `README.md`. For a one-page reminder once
you're familiar, see `QUICK_START.md`.

---

## 1. What this program does

You give it two (optionally three) files each month:

1. Your **Project Tracking** spreadsheets (one `.xlsx` per project)
2. Your **Clockify** time export
3. *(Optional)* your accounting **Profit & Loss** export

It produces two outputs:

- **`Profit_Ledger.html`** — an interactive dashboard you open in any web
  browser. Eight sections: headline KPIs, monthly trends, financial-year
  comparisons (including revenue per engineering hour), a month-by-month
  heatmap, project league tables, client relationships, engineer fee
  attribution, the cash runway, and a projection of the current financial year
  against prior years.
- **`Project_Profitability_Analysis.xlsx`** — a nine-sheet Excel companion
  with the same numbers in spreadsheet form.

Everything runs **locally on your PC**. No internet connection is used and no
data leaves your machine.

---

## 2. One-time setup

### Step A — Check you have Python

The program needs Python 3.9 or newer (a free programming language runtime).

- **Windows**: open the Start menu, type `cmd`, press Enter, then type
  `python --version` and press Enter.
- **Mac**: open Terminal (Applications → Utilities), type `python3 --version`.

If you see a version number of 3.9 or higher, you're ready. If not, download
Python from **https://www.python.org/downloads/** and install it.
**Windows users: on the installer's first screen, tick the box that says
"Add Python to PATH"** — this matters.

### Step B — Choose a home for the program

Unzip `profit_ledger.zip` anywhere convenient — for example:

```
Windows:  C:\Users\<you>\Documents\Profit_Ledger\
Mac:      /Users/<you>/Documents/Profit_Ledger/
```

Everything lives inside this one folder. To uninstall later, just delete the
folder — nothing is installed anywhere else on your system.

### Step C — Run the installer (once only)

- **Windows**: open the folder and double-click **`install.bat`**
- **Mac/Linux**: open Terminal in the folder and run:
  `chmod +x install.sh run.sh` then `./install.sh`

A black window will show progress for about a minute. It creates a private
copy of the four software libraries the program needs, inside a hidden
`.venv` folder. When it says installation is complete, you're done — you never
need to run this again (unless you move to a new PC).

---

## 3. Know your folder

```
Profit_Ledger/
│
├── install.bat / install.sh   ← one-time setup (already done)
├── run.bat     / run.sh       ← THE BUTTON YOU PRESS EACH MONTH
├── config.json                ← settings (see section 6)
│
├── data/                      ← YOUR INPUT FILES GO HERE
│   ├── Project_Tracking/      ←   all project .xlsx files
│   ├── Clockify_Export.xlsx   ←   the Clockify export
│   └── Profit_and_Loss.xlsx   ←   (optional) accounting P&L
│
├── outputs/                   ← RESULTS APPEAR HERE
│   ├── Profit_Ledger.html
│   └── Project_Profitability_Analysis.xlsx
│
├── archive/                   ← dated copies pile up automatically
├── README.md                  ← full reference guide
├── QUICK_START.md             ← one-page reminder
└── src/                       ← the program code (no need to open)
```

---

## 4. The monthly routine

### Step 1 — Refresh the data

**Project Tracking files** → copy your latest project `.xlsx` files into
`data/Project_Tracking/`, replacing what's there. One file per project. Both
the new template files (names like `001.CATS_01.xlsx`, with a *Project
Definition* sheet) and the older layout (a *Monthly* sheet) are understood —
the pipeline works out which is which on its own, and a mixture of the two is
fine while you migrate. Just avoid having the *same* project present in both
formats at once. It's fine to copy the whole set every month — new projects
are picked up automatically, and template/resource/lock files (names beginning
`20260`, `001_`, `~`, including behind a `001.` prefix such as
`001.001_Resource.xlsx`) are ignored.

**Clockify export** → in Clockify, run the *Detailed Report* for **all time**
(the full history, not just the month), export to Excel, and save it as:

```
data/Clockify_Export.xlsx
```

— exactly that name, replacing last month's copy.

**Profit & Loss (optional but recommended)** → export a monthly P&L from your
accounting system (e.g. Xero) covering as many months as it offers, and save
it as:

```
data/Profit_and_Loss.xlsx
```

This feeds the dashboard's Part VIII comparison of the current year against
prior years' actual accounts. If the file isn't there, that panel simply
hides and everything else runs normally. The program reads the P&L by row
labels and copes with exports whose subtotal rows come through blank.

### Step 2 — Update your cash figure (recommended)

Open `config.json` (right-click → Open with → Notepad on Windows, TextEdit on
Mac) and set `runway_starting_cash` to your actual bank balance, e.g.:

```json
"runway_starting_cash": 550000,
```

Save and close. This keeps the runway projection anchored to reality. (See
section 6 for the burn-rate setting.)

### Step 3 — Run

- **Windows**: double-click **`run.bat`**
- **Mac/Linux**: `./run.sh`

About 30 seconds. The window prints the headline figures as it works and tells
you when it's finished.

### Step 4 — Open the results

Go to the `outputs/` folder and double-click **`Profit_Ledger.html`** — it
opens in your web browser. Everything on it is interactive: drag the date
sliders, click table headers to sort, click clients to expand them, adjust the
runway assumptions and watch the projections recompute. Nothing you do in the
browser changes the underlying data — refresh the page to reset.

The Excel companion sits alongside it.

A dated copy of both outputs is also filed automatically under
`archive/<date>/`, so you build up a month-by-month history without doing
anything.

---

## 5. How the program decides "which month" to analyse

You don't normally need to set the reporting date. The program looks at your
Clockify data and uses the **end of the most recent completed month** — if
your export runs to the 29th of June, it reports to 30 June; if you export a
few days into July, it still reports to 30 June (it won't treat a few days of
July as a whole month). To force a specific date, set `"cutoff_month_end"` in
`config.json`, e.g. `"2026-06-30"`; set it back to `null` for automatic.

---

## 6. Two settings worth knowing about

Both live in `config.json`:

**`runway_starting_cash`** — your cash at the reporting date. Update monthly
(step 2 above).

**`runway_monthly_burn`** — the monthly operating cost used in the runway and
year-projection. Currently set from the accounting P&L (Cost of Sales +
Administrative Costs, averaged over the current financial year's complete,
normal months). Leave it as-is between accounting updates. When a new P&L
arrives, the honest approach is to recompute that average and update the
number. Set it to `null` and the program will instead estimate burn from
subcontractor costs + time at billable rates — a rougher proxy that misses
overheads. You can also try different burn rates live in the dashboard
(Part VII) without changing this file.

Everything else in `config.json` can be left alone. The full list is explained
in `README.md` §6.

---

## 7. As time goes on

- **Monthly**: repeat section 4. That's it.
- **Archives**: the `archive/` folder grows one dated subfolder per run. Old
  ones can be deleted freely if space matters — they're just copies.
- **New projects**: just drop their tracking files into
  `data/Project_Tracking/` along with the rest.
- **The new file format is the norm from here**: as projects move onto the
  `001.XXXX_NN.xlsx` template files, simply replace the old file with the new
  one in `data/Project_Tracking/` (never keep both for the same project). Once
  migration is complete the folder will contain only new-format files, and the
  monthly routine is to overwrite the whole set with the latest copies from
  wherever the templates live.
- **New financial year**: nothing to do — the FY tables, heatmap, and
  year-projection roll forward automatically (the financial year runs
  August–July).
- **Moving to a new PC**: copy the whole folder, delete the hidden `.venv`
  folder inside it, and run the installer once on the new machine.

---

## 8. If something goes wrong

The program's error messages are written to be read — they say what's missing
and where to put it. The three most common:

| Message | Fix |
|---|---|
| "Virtual environment not found" | Run `install.bat` / `install.sh` first |
| "Clockify export not found" | Save the export as `data/Clockify_Export.xlsx` — exact name |
| "No Project Tracking files found" | Put your project `.xlsx` files in `data/Project_Tracking/` |

If the dashboard opens but a section looks wrong, check the matching input
file is current, re-run, and refresh the browser. Deeper troubleshooting is in
`README.md` §9.
