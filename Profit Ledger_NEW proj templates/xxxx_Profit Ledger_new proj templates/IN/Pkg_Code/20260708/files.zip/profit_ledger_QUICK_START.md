# Quick Start — Profit Ledger

A one-page guide for users who've done the install once already. Stick this on your monitor.

---

## To run the analysis each month

### 1. Refresh the data
Drop these into the package:

| Where | What |
|---|---|
| `data/Project_Tracking/` | Latest Project Tracking `.xlsx` files (one per project, overwrite or add new). New `001.XXXX_NN` template files and legacy files both work — auto-detected |
| `data/Clockify_Export.xlsx` | Latest "Detailed Report" export from Clockify, saved as this exact filename |
| `data/Profit_and_Loss.xlsx` | *(Optional)* Latest accounting P&L export — drives the Part VIII three-year comparison |

### 2. Run it
- **Windows**: double-click `run.bat`
- **macOS / Linux**: `./run.sh` from a terminal in this folder

Takes about 30 seconds. Headline figures appear in the console.

### 3. Open the outputs
- `outputs/Profit_Ledger.html` — double-click to open in your browser
- `outputs/Project_Profitability_Analysis.xlsx` — open in Excel

A dated copy is automatically saved to `archive/{cutoff-date}/`.

---

## To adjust assumptions

Open `config.json` in any text editor and edit the values. The most useful three:

```json
"runway_starting_cash": 420000,        ← update with current bank balance
"runway_monthly_burn":  86051,         ← baseline £/month burn (or null = auto-detect)
"cutoff_month_end":     null,          ← set to specific date or null = auto-detect
```

**Save the file**, then re-run. Don't add comments — JSON doesn't allow them.

For finer control inside the dashboard itself, use the interactive sliders in Part VII (runway). Those changes don't write back to `config.json`; they're for live what-if exploration.

---

## To use the dashboard

| To do this | Look here |
|---|---|
| See a specific date range's KPIs | Drag Part I sliders — top row updates with oxblood accent |
| Compare FYs as share of total | Part II — toggle "% of total" |
| Switch heatmap colour basis | Part III — toggle Profit / Margin / Instalments / Hours |
| See best projects in any period | **Part IV — drag the Time window slider** |
| Find a specific project | Part IV — type in the search box |
| See a client's portfolio | Part V — click their row to expand |
| See who drove a specific FY | Part VI — click that FY's column header |
| Model cash scenarios | Part VII — drag the four sliders (incl. **monthly burn £/mo**) |
| See projected current-FY profit | Part VIII — recomputes live from the Part VII burn |

---

## If something goes wrong

| Symptom | Fix |
|---|---|
| "Python is not recognized" | Reinstall Python, tick "Add to PATH" |
| "Project Tracking folder not found" | Confirm `data/Project_Tracking/` exists with .xlsx files inside |
| "Clockify export not found" | Confirm `data/Clockify_Export.xlsx` exists (exact name) |
| "config.json is not valid JSON" | Validate at <https://jsonlint.com> |
| Headline figures haven't changed | Check the date range of your Clockify export |
| Dashboard typography looks plain | You're offline; web fonts didn't load. Data is still correct |

The full reference is in `README.md`.
