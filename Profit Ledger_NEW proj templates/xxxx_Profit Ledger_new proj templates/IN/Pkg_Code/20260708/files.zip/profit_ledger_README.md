# The Profit Ledger

A self-contained analysis pipeline that turns your Project Tracking spreadsheets and Clockify time-tracking exports into an interactive profitability dashboard. Re-run it each month to roll the picture forward.

> **First time here?** Read **`SETUP_AND_OPERATION_GUIDE.md`** — a plain-English walkthrough of setup, the folder, the monthly data routine, and running the program. This README is the fuller technical reference.

---

## What you get

Two outputs every time you run it:

| | What it is | Best for |
|---|---|---|
| `outputs/Profit_Ledger.html` | A broadsheet-style interactive dashboard | Reading and exploring — open in any web browser, works offline |
| `outputs/Project_Profitability_Analysis.xlsx` | Nine spreadsheet tabs of the same data | Filtering, pivoting, deep exploration in Excel |

Both are also automatically copied into `archive/{cutoff-date}/` after each run, so you have a permanent record of how the figures looked at each month-end.

### What's in the dashboard

The HTML dashboard has eight sections, each with live interactive controls:

| Section | What it shows | Interactive |
|---|---|---|
| **KPI Row** (top) | Five hero figures — instalments, subcontractors, time delivered, net profit & margin, engagements | Recompute when Part I's brush is moved |
| **Part I — The arc of fee and time** | Monthly trend chart, instalments vs time vs subcontractors | Date-range brush (two sliders) — zoom into any window |
| **Part II — By financial year** | Annual aggregates incl. revenue per engineering hour | Absolute / share-of-total toggle |
| **Part III — Twelve months an FY** | Calendar heatmap | Switch colour basis (profit / margin / instalments / hours); colour key updates |
| **Part IV — Projects in profit / at a loss** | Every engagement ranked | Search, min-instalments filter, sortable columns, **time-window slider** (recomputes profit/loss for any period) |
| **Part V — The relationships** | Profit by client | Click any client to drill into their projects |
| **Part VI — The team** | Engineer fee attribution by FY | Click any FY column to re-sort |
| **Part VII — The runway** | Cash-flow projection with overlays for "1 year ago" and "2 years ago" comparisons | Four assumption sliders (including **monthly burn rate**) + two historical cash inputs |
| **Part VIII — The year in prospect** | Projected current-FY turnover, burn and profit, alongside the prior two financial years from the accounts | Recomputes live from Part VII's burn rate |

All computation happens client-side in your browser — there's no server, no cloud, nothing phones home. Once generated, the HTML file is fully portable; you can email it to a colleague and it'll open anywhere.

---

## 1. Installing — first time only

### Before you start

You need **Python 3.9 or later** on your computer. To check whether you have it, open a terminal:

- **Windows**: press **Win + R**, type `cmd`, press Enter
- **macOS**: open **Terminal** from Applications → Utilities (or press **Cmd + Space**, type "Terminal")

Type this and press Enter:

```
python --version
```

If you see something like `Python 3.11.5`, you're set. Skip to "Running the installer" below.

If you see "command not found" or "'python' is not recognized", you need to install Python:

- **Windows**: download from <https://www.python.org/downloads/>. **Important**: when the installer runs, tick the box that says *"Add python.exe to PATH"* before clicking Install. If you forget, you'll have to uninstall and reinstall.
- **macOS**: Python 3 is usually preinstalled. If not, install via Homebrew (`brew install python`) or download from <https://www.python.org/downloads/macos/>.
- **Linux (Ubuntu/Debian)**: `sudo apt install python3 python3-venv` in a terminal.

### Running the installer

Once Python is in place:

- **Windows**: double-click `install.bat`. A console window opens, takes about a minute, and closes when done. Press a key to close.
- **macOS / Linux**: open a terminal in this folder and run:
  ```
  chmod +x install.sh run.sh
  ./install.sh
  ```

The installer creates an isolated Python environment inside the package (`.venv/`) and installs four small libraries (pandas, openpyxl, numpy, python-dateutil). **Nothing is installed to your system Python.** If you ever want to uninstall, just delete the entire package folder.

---

## 2. Running the analysis — every month

Three steps. About one minute of your time.

### Step 1 — Refresh the data

1. **Project Tracking files.** Copy your latest Project Tracking `.xlsx` files into:
   ```
   data/Project_Tracking/
   ```
   One file per project. **Both file layouts are read, auto-detected per file** — the new template files (a `Project Definition` sheet, filenames like `001.CATS_01.xlsx`) and the legacy layout (a `Monthly` sheet). A folder can hold a mixture of the two, which makes mid-migration runs safe — just don't include the *same* project in both formats at once, or its fees will be counted twice. You can overwrite existing files or add new ones — the pipeline picks up whatever is there. Templates, resource files and lock files are skipped automatically: names starting `20260`, `001_`, or `~` — and a `NNN.` sequencing prefix (as in `001.001_Resource.xlsx`) is ignored when applying those rules, so mapped resource files are still skipped.

2. **Clockify export.** In Clockify, run the **Detailed Report** for the full date range you care about, and export it to Excel. Save the file (replacing any older copy) as:
   ```
   data/Clockify_Export.xlsx
   ```
   Use this exact filename. The pipeline looks for it by name.

3. **(Optional) Profit & Loss export.** If you have a recent monthly P&L from your accounting system (e.g. a Xero "Profit and Loss" export), save it as:
   ```
   data/Profit_and_Loss.xlsx
   ```
   The pipeline uses this for the **three-year comparison panel in Part VIII** — projected current-year turnover and profit shown alongside the prior two financial years' actuals. If this file is absent the comparison panel is simply hidden and everything else runs as normal.

### Step 2 — Run

- **Windows**: double-click `run.bat`
- **macOS / Linux**: `./run.sh` from a terminal in this folder

You'll see progress messages and a summary like this:

```
======================================================================
HEADLINE FIGURES
======================================================================
  Total instalments raised:     £  5,202,376.90
  Total subcontractor costs:    £    501,477.00
  Total Clockify billable time: £  3,529,633.00
  -----------------------------------------------
  Profit:                       £  1,171,266.90
  Margin:                                 22.51%
  Projects in profit / loss:    148 / 61
======================================================================
```

Sanity-check that the figures look right before opening the outputs.

### Step 3 — Open the outputs

- **`outputs/Profit_Ledger.html`** — double-click to open in your default browser. This is the main report.
- **`outputs/Project_Profitability_Analysis.xlsx`** — open in Excel for detailed exploration.

A dated copy of both has been saved to `archive/{cutoff-date}/` so you can always go back and see what the picture looked like at any previous month-end.

---

## 3. The cutoff date

By default the pipeline uses **the end of the most recent complete month found in the Clockify data** as the cutoff. So if your Clockify export runs to 29 May 2026, the cutoff will be 31 May 2026.

If you want to lock the report to a specific cutoff (e.g. end-of-April even though Clockify already has some May entries), edit `config.json` and set:

```json
"cutoff_month_end": "2026-04-30"
```

To return to auto-detection, set it back to `null`:

```json
"cutoff_month_end": null
```

After editing `config.json`, save it and re-run. You don't need to reinstall.

---

## 4. The Runway analysis

Part VII of the dashboard models how long the business stays solvent under various assumptions. Two values you may want to update each month in `config.json`:

```json
"runway_starting_cash": 420000,
"runway_burn_escalation": 0.10,
"runway_monthly_burn": 86051
```

- **`runway_starting_cash`** — cash on hand at the cutoff date. Update this every month so the headline number reflects reality.
- **`runway_burn_escalation`** — assumed year-on-year cost growth (0.10 = 10%), compounded across FYs.
- **`runway_monthly_burn`** — the baseline monthly burn (£/month). Set to a number to fix the burn rate by hand (recommended: derive it from your accounting P&L — Cost of Sales + Admin, averaged across complete months of the current FY). Set to `null` to auto-detect from the current-FY average of subcontractor + Clockify-billable costs (a proxy that values delivered time at billable rates and omits overheads).

You can also adjust all four assumptions **live in the dashboard** via Part VII — useful for what-if exploration. The monthly burn is an absolute £/month figure; the auto-detected proxy value is always shown beside the control as a reference. Live changes don't write back to `config.json`; they reset to the config values each time you reopen the file.

The dashboard also overlays the runway as it would have looked **one and two years ago** for comparison. The historical cash positions default to £100,000 each (since the pipeline doesn't have your past cash records) and can be adjusted inline in the dashboard.

**Part VIII** uses the same burn rate to project the current financial year's full-year outturn (turnover, burn, profit, margin) and — if a P&L file is present — places it alongside the prior two complete financial years from the accounts. The projection recomputes live as you move the Part VII burn control.

---

## 5. The methodology

Baked into the pipeline:

- **Profit formula**: Monthly Profit = Instalment Due (col O of Project Tracking) − Subcontractor costs (col CW) − Clockify Billable Amount GBP (col S of Clockify). All in-period monthly figures.
- **Cumulative Fee (col P)**: shown in the Excel detail sheet for context, not used in the profit calculation.
- **Project Expenses (col Q)**: excluded — pass-through to client at cost.
- **JGC_Company and JGC_Dev**: excluded by default — internal time codes, not client work.
- **Engineer attribution (Part VI)**: within each project, within each financial year, the top four engineers by Clockify hours are credited. Each gets a share of that project's fee proportional to their hours in that FY. Engineers ranked 5th or lower get nothing. `Dan` and `Pelifa French` are excluded by default.
- **Financial year**: August to July (matches the academic-year cycle of college clients). Partial FYs are flagged.
- **Engagement count**: distinct project IDs with any activity (instalment or time logged) in the analysed window.

The pipeline is **idempotent** — running it twice with the same inputs gives identical outputs. Safe to re-run.

---

## 6. Config reference

`config.json` controls everything. Open it in any text editor (Notepad, TextEdit, VS Code), edit the values, save. Don't add comments — JSON doesn't support them, and the file must remain valid JSON or the pipeline will refuse to start.

| Key | Type | Default | What it controls |
|---|---|---|---|
| `cutoff_month_end` | string or `null` | `null` | Last month to include, e.g. `"2026-05-31"`. `null` = auto-detect from Clockify data. |
| `project_tracking_folder` | string | `"data/Project_Tracking"` | Where to find the Project Tracking files. |
| `clockify_export_path` | string | `"data/Clockify_Export.xlsx"` | Where to find the Clockify export. |
| `excel_output` | string | `"outputs/Project_Profitability_Analysis.xlsx"` | Where to write the Excel workbook. |
| `html_output` | string or `false` | `"outputs/Profit_Ledger.html"` | Where to write the HTML. Set to `false` to skip HTML. |
| `archive_outputs` | bool | `true` | If `true`, copy outputs to a dated subfolder under `archive/`. |
| `archive_folder` | string | `"archive"` | Where archived copies go. |
| `excluded_projects` | list of strings | `["JGC_Company", "JGC_Dev"]` | Project IDs to omit from the analysis. |
| `excluded_engineers` | list of strings | `["Dan", "Pelifa French"]` | Engineers omitted from Part VI fee attribution. |
| `runway_starting_cash` | number | `420000` | Cash on hand at the cutoff date (£). |
| `runway_burn_escalation` | number | `0.10` | Year-on-year cost growth, compounded (0.10 = 10%). |
| `runway_monthly_burn` | number or `null` | `86051` | Baseline monthly burn rate (£/month) used by Part VII and Part VIII. Set to `null` to auto-detect from the Clockify-derived proxy. |
| `profit_loss_path` | string or `null` | `"data/Profit_and_Loss.xlsx"` | Path to an accounting P&L export. Used for Part VIII's three-year comparison. Omit, or leave the file absent, to hide the comparison panel. |
| `runway_max_horizon_months` | integer | `84` | How many months the runway model projects (84 = 7 years). |
| `filename_skip_prefixes` | list of strings | `["20260", "001_", "~"]` | Files in `data/Project_Tracking/` whose names start with any of these are skipped. |

All paths can be **relative** (resolved from the package root) or **absolute**. The package root is the folder containing `config.json`.

---

## 7. The folder structure

```
profit_ledger_dist/
├── README.md                ← you are here
├── QUICK_START.md           ← one-page cheat sheet for monthly runs
├── DESIGN_SYSTEM.md         ← visual identity reference for future docs
├── DESIGN_SWATCH.html       ← visual swatch sheet (open in browser)
├── config.json              ← all settings — edit this for tweaks
├── requirements.txt         ← Python dependencies (managed by install scripts)
├── install.bat              ← Windows: one-time setup
├── install.sh               ← macOS/Linux: one-time setup
├── run.bat                  ← Windows: monthly run
├── run.sh                   ← macOS/Linux: monthly run
├── .venv/                   ← created by install (don't touch or commit)
├── src/
│   ├── run_analysis.py      ← the analysis engine
│   └── ledger_template.html ← HTML layout & styling
├── data/
│   ├── Project_Tracking/    ← DROP YOUR .xlsx FILES HERE
│   ├── Clockify_Export.xlsx ← SAVE YOUR CLOCKIFY EXPORT HERE
│   └── Profit_and_Loss.xlsx ← (OPTIONAL) ACCOUNTING P&L EXPORT
├── outputs/                 ← regenerated each run
│   ├── Profit_Ledger.html
│   └── Project_Profitability_Analysis.xlsx
└── archive/                 ← dated copies accumulate here
    └── 2026-05-31/
        ├── Profit_Ledger.html
        └── Project_Profitability_Analysis.xlsx
```

---

## 8. Using the interactive dashboard

The HTML report is more than a snapshot — it's a tool. Here are the most useful interactions:

**To zoom into a specific period**: drag the sliders in Part I. The chart rescales AND the top KPI row updates — you'll see "Showing figures for the period Sep 2023 to May 2026" appear, with the KPIs recomputed for that window. Use the "Show full period" link in the banner to reset.

**To see what each FY looked like**: in Part II, click the "% of total" toggle to switch from pounds to share — useful for spotting that, say, FY 2024/25 alone drove 28% of all-time profit.

**To explore the seasonal shape of the business**: in Part III, switch the "Colour by" toggle between Profit / Margin / Instalments / Hours. The colour key updates to show the actual value range. The Hours view in particular reveals headcount growth as cell density increases year-on-year.

**To find which projects mattered most in a specific period**: in Part IV, use the **Time window** slider at the bottom of the controls. The league tables recompute profit/loss for projects within that window only. So you can answer "who were the best-earning projects in FY 2023/24?" — which might be completely different from the lifetime ranking.

**To compare clients**: in Part V, click any client row to drill into all their engagements. Multiple clients can be expanded simultaneously.

**To see who's driven each year**: in Part VI, click any FY column header to sort by that year's contribution. Year-on-year shifts in who's pulling the weight become obvious.

**To model cash scenarios**: in Part VII, drag any of the four sliders (starting cash, escalator, monthly burn £/mo, new work). The "1 year ago" and "2 years ago" dashed overlay lines let you see whether the trajectory is improving or worsening over time. Part VIII updates live with whatever burn rate you set.

---

## 9. Troubleshooting

**"Python is not recognized" or "command not found" (Windows)**
Python wasn't added to your PATH during installation. Reinstall Python from <https://www.python.org/downloads/> and tick *"Add python.exe to PATH"* before clicking Install.

**"Project Tracking folder not found"**
Check that `data/Project_Tracking/` exists and contains your .xlsx files. If you've put the data elsewhere, update `project_tracking_folder` in `config.json`.

**"No Project Tracking .xlsx files found"**
The folder exists but is empty (apart from any placeholder README files). Drop your `.xlsx` files in.

**"Clockify export not found"**
The file needs to be at `data/Clockify_Export.xlsx` with that exact name. If yours has a date in the name like `Clockify_Detailed_Report_May2026.xlsx`, rename it.

**"config.json is not valid JSON"**
Almost always a missing or extra comma. Open `config.json` in a text editor and check the line near the error. JSON doesn't tolerate trailing commas. A site like <https://jsonlint.com> can pinpoint the problem.

**Headline figures haven't changed since last time**
Most likely cause: the data files are the same. Check that you actually updated them. The auto-detected cutoff is based on the latest Clockify entry, so if the export hasn't moved forward, the cutoff won't either.

**Dashboard charts look basic without elegant typography**
Your machine is offline. The fonts (Source Serif 4, Spectral, JetBrains Mono) load from Google Fonts. Data and interactivity still work, but typography falls back to system fonts.

**Excel formulas show #VALUE! errors**
The workbook may need Excel to "Enable Editing" when first opened. Press **Ctrl + Alt + F9** (Windows) or **Cmd + Alt + F9** (Mac) to force a recalculation.

**The runway figure looks wrong**
The model assumes (a) every future instalment booked into Project Tracking actually lands on schedule, (b) no new work is won, (c) costs grow as configured. If reality has diverged, adjust the live sliders in Part VII to test alternative scenarios. Update `runway_starting_cash` in config.json to reflect your actual current cash position.

---

## 10. Backing up

Two files are the entire pipeline — everything else is either input or output:

- `src/run_analysis.py` — the analysis engine
- `src/ledger_template.html` — the dashboard design

Keep them in version control (Git) or copied somewhere safe and dated. The `archive/` folder preserves a record of every month's output. The `outputs/` folder is regenerated each run, so anything you need to keep should be copied out or relied on via the archive.

---

## 11. Customising the analysis

Most changes go in `config.json`. For deeper changes — a different profit formula, additional dashboard sections — you can edit `src/run_analysis.py` (the engine) or `src/ledger_template.html` (the layout). Both have detailed comments explaining what each part does. The pipeline is about 1,730 lines of Python; readable in an afternoon.

---

## 12. Design system

For designers and developers creating future documents that should feel like part of the Profit Ledger family (board memos, financial proposals, capability decks, project post-mortems, etc.), the visual language is documented in two files:

- **`DESIGN_SYSTEM.md`** — the full reference. Colours, typography, components, layout grammar, voice and tone. Includes design tokens ready to paste into a new document.
- **`DESIGN_SWATCH.html`** — a one-page visual reference showing each colour swatch, each type specimen, and example components rendered in the language. Open it in any browser.

Read these before designing a new document in the family. The aim is for new documents to feel like they belong alongside the Ledger without needing to look identical — same palette, same fonts, same layout grammar, same voice.

---

## 13. What's new in this version

Most recent changes first:

- **New Project Tracking layout supported (Project Definition files).** The pipeline now reads the new template-based project files — a `Project Definition` sheet with a project metadata block (Job Code, Client, …) and a one-row-per-month table of up to 12 fee lines, 5 subcontractor cost lines and 3 expense lines per month. Monthly gross fee, subcontractor cost and expenses are summed from the individual lines (the sheet's Total columns are Excel formulas that carry no cached values in template-generated files, so they are not relied upon; a hard-typed value in a Total cell is still picked up if the line cells are empty). Project ID and Client come from the metadata block. The legacy `Monthly`-sheet layout still works, formats are auto-detected per file, and a folder may contain a mixture of both. Validated against the manual mapping set: 200 projects, instalments and subcontractor costs reconcile **exactly** (£7,251,424.71 / £639,420.90) between the two layouts, and dashboards produced from each are identical apart from three client names that were deliberately corrected in the new files.

- **Revenue per engineering hour** (Part II, and the Excel Yearly Rollup). A new "Rev / hr" column showing fee instalments raised divided by hours logged, per financial year — how much fee each delivered hour earns. Stays as a £/hour rate under the "% of total" toggle; the total row uses the properly weighted figure.
- **Top-four engineer attribution** (Part VI). Within each project and financial year, the top **four** engineers by hours are now credited (previously three); each gets a share of the fee proportional to their hours, and anyone ranked fifth or lower gets nothing.
- **Smarter cutoff auto-detection.** When no `cutoff_month_end` is set, the pipeline takes the end of the most recent *completed* month. The latest month in the data counts as complete only if its final entry falls within three days of the month-end — so a fresh export taken a few days into a new month no longer drags a partial month into the analysis. Pin `cutoff_month_end` in `config.json` to override.

Part VIII / burn / P&L release:

- **Part VIII — The year in prospect.** New section at the bottom of the dashboard. Projects the current financial year's full-year turnover, burn and profit, using fees raised to date + booked future fees through year-end, set against the Part VII burn rate. Recomputes live as you adjust the burn.
- **Three-year comparison panel** (Part VIII, right-hand side). Places the projected current year alongside the prior two **complete** financial years' actuals taken straight from your accounting P&L (turnover and operating profit). Comparatives are read by row label, so the panel is robust to slightly different P&L layouts. If you don't supply a P&L file, the panel simply hides.
- **Monthly burn rate control** (Part VII). Replaces the earlier "burn vs current" percentage with an **absolute £/month** input. The auto-detected Clockify-derived proxy is always shown alongside as a reference. Set a baseline in `config.json` (`runway_monthly_burn`) — recommended: derive it from your accounting P&L so it reflects real overheads, not just billable time.
- **Optional P&L input.** Drop a monthly P&L export (e.g. from Xero) into `data/Profit_and_Loss.xlsx` to drive the Part VIII comparatives. Configurable via `profit_loss_path` in `config.json`. Treated as user data — it lives only in your local copy.

Earlier in this release line:

- **Time-window slider in Part IV** — slide a date range and the league tables recompute profit/loss within just that window. Distinct projects with no activity in the window disappear; ones that performed well in that specific period rise to the top.
- **KPI windowing** — moving the Part I trend brush also recomputes the top KPI row, with a clear visual cue (oxblood accent, banner) when you're looking at a windowed view rather than lifetime totals.
- **Colour key in Part III** — gradient bar beneath the heatmap toggle showing what the intensity scale means, updating with each basis switch.
- **Palette consistency in Part IV** — profit bars now in ink navy (matching Part III), at 1.5px thickness for visual parity with loss bars.
- **Runway historical overlays** — two dashed lines showing the runway as it would have looked 1 and 2 years ago, aligned by months-from-anchor, with adjustable historical cash inputs.
- **Auto-archiving** — every run now copies outputs to `archive/{cutoff-date}/` automatically.
- **Friendly errors** — missing data files now produce clear messages telling you what's missing and where to put it.
- **Design system documentation** — `DESIGN_SYSTEM.md` and `DESIGN_SWATCH.html` codify the visual language for future documents.
